import React, { useState, useEffect } from 'react';
import { FileText, AlertCircle, Search } from 'lucide-react';
import { api } from '../../services/api';
import type { ConsentForm } from '../../services/types';
import { DigitalSignature } from './components/DigitalSignature';
// import clsx from 'clsx';

export const ConsentsPage: React.FC = () => {
    const [forms, setForms] = useState<ConsentForm[]>([]);
    const [selectedForm, setSelectedForm] = useState<ConsentForm | null>(null);
    const [signingMode, setSigningMode] = useState(false);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadForms();
    }, []);

    const loadForms = async () => {
        setLoading(true);
        try {
            const data = await api.consents.listForms();
            setForms(data);
        } finally {
            setLoading(false);
        }
    };

    const handleSign = async (_signature: string) => { // used in next iteration
        if (!selectedForm) return;
        alert(`Signed ${selectedForm.title} successfully!`);
        setSigningMode(false);
        setSelectedForm(null);
    };

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-white">Digital Consents</h1>
                    <p className="text-text-muted">Manage templates and sign consents.</p>
                </div>
                <div className="relative w-64">
                    <input
                        type="text"
                        placeholder="Search templates..."
                        className="w-full bg-bg-secondary border border-border rounded-lg pl-10 pr-4 py-2 text-white outline-none focus:ring-2 focus:ring-accent"
                    />
                    <Search className="absolute left-3 top-2.5 text-text-muted" size={18} />
                </div>
            </div>

            {signingMode && selectedForm ? (
                <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
                    <div className="max-w-2xl w-full flex flex-col gap-6">
                        <div className="bg-white rounded-lg p-6 max-h-[400px] overflow-y-auto">
                            <h2 className="text-2xl font-bold text-black mb-4">{selectedForm.title}</h2>
                            <div className="prose text-gray-700">
                                <p>{selectedForm.content}</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                            </div>
                        </div>
                        <DigitalSignature
                            onSave={handleSign}
                            onClear={() => { }}
                        />
                        <button onClick={() => setSigningMode(false)} className="text-white hover:text-gray-300 text-center">
                            Cancel
                        </button>
                    </div>
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {loading ? (
                        <div className="text-text-muted">Loading forms...</div>
                    ) : forms.map(form => (
                        <div key={form.id} className="bg-bg-secondary border border-border rounded-lg p-6 hover:border-accent/50 transition-colors flex flex-col h-full">
                            <div className="flex items-start justify-between mb-4">
                                <FileText className="text-accent" size={32} />
                                {form.required_signature && (
                                    <span className="bg-red-500/10 text-red-500 text-xs px-2 py-1 rounded font-medium flex items-center gap-1">
                                        <AlertCircle size={12} /> Required
                                    </span>
                                )}
                            </div>
                            <h3 className="text-xl font-bold text-white mb-2">{form.title}</h3>
                            <p className="text-text-muted text-sm line-clamp-2 mb-6 flex-1">
                                {form.content}
                            </p>
                            <div className="flex gap-2 mt-auto">
                                <button className="flex-1 py-2 bg-bg-tertiary border border-border rounded-lg text-white hover:bg-white/10 transition-colors text-sm font-medium">
                                    Preview
                                </button>
                                <button
                                    onClick={() => { setSelectedForm(form); setSigningMode(true); }}
                                    className="flex-1 py-2 bg-accent hover:bg-accent-hover text-white rounded-lg transition-colors text-sm font-medium shadow-lg shadow-accent/20"
                                >
                                    Sign
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};
