import React, { useEffect, useState } from 'react';
import { api } from '../../services/api';
import type { WaitlistEntry } from '../../services/types';
import { Search, Filter, QrCode, CheckCircle, XCircle, Clock, UserPlus } from 'lucide-react';
import clsx from 'clsx';
import { useAuth } from '../auth/AuthContext';

export const WaitlistManager: React.FC = () => {
    const { user } = useAuth();
    const [entries, setEntries] = useState<WaitlistEntry[]>([]);
    const [loading, setLoading] = useState(true);
    const [showQr, setShowQr] = useState(false);

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        setLoading(true);
        try {
            const data = await api.waitlist.list(user?.studio_id || 'studio-1');
            setEntries(data);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    const handleStatusUpdate = async (id: string, status: WaitlistEntry['status']) => {
        try {
            await api.waitlist.updateStatus(id, status);
            loadData();
        } catch (err) {
            alert('Errore aggiornamento stato');
        }
    };

    const publicLink = `${window.location.origin}/public/waitlist/${user?.studio_id || 'studio-1'}`;

    return (
        <div className="p-8 max-w-7xl mx-auto space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2">Lista d'Attesa</h1>
                    <p className="text-text-muted">Gestisci le richieste di appuntamento in arrivo.</p>
                </div>
                <div className="flex gap-3">
                    <button
                        onClick={() => setShowQr(!showQr)}
                        className="flex items-center gap-2 bg-bg-tertiary hover:bg-white/10 text-white px-4 py-2 rounded-lg border border-border transition-colors"
                    >
                        <QrCode size={20} />
                        {showQr ? 'Nascondi QR' : 'Mostra QR Code'}
                    </button>
                </div>
            </div>

            {/* QR Code Section */}
            {showQr && (
                <div className="bg-white p-6 rounded-xl border border-border shadow-xl max-w-sm mx-auto text-center transform transition-all animate-in fade-in slide-in-from-top-4">
                    <h3 className="text-black font-bold text-lg mb-4">Scansiona per Iscriverti</h3>
                    <div className="bg-gray-100 p-4 rounded-lg inline-block mb-4">
                        <img
                            src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(publicLink)}`}
                            alt="QR Code"
                            className="w-48 h-48 mix-blend-multiply"
                        />
                    </div>
                    <p className="text-gray-500 text-xs break-all px-4">{publicLink}</p>
                    <button
                        onClick={() => window.open(publicLink, '_blank')}
                        className="mt-4 text-accent text-sm font-medium hover:underline"
                    >
                        Apri Link
                    </button>
                    <button
                        onClick={() => window.print()}
                        className="mt-2 block w-full text-gray-400 text-xs hover:text-black"
                    >
                        Stampa
                    </button>
                </div>
            )}

            {/* Filters (Mock UI) */}
            <div className="flex gap-4 mb-6">
                <div className="relative flex-1 max-w-sm">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" size={18} />
                    <input
                        type="text"
                        placeholder="Cerca per nome..."
                        className="w-full bg-bg-secondary border border-border rounded-lg pl-10 pr-4 py-2 text-white focus:border-accent focus:outline-none"
                    />
                </div>
                <button className="flex items-center gap-2 px-4 py-2 bg-bg-secondary border border-border rounded-lg text-text-muted hover:text-white">
                    <Filter size={18} /> Filtra
                </button>
            </div>

            {/* List */}
            <div className="bg-bg-secondary rounded-xl border border-border overflow-hidden">
                <table className="w-full text-left">
                    <thead className="bg-bg-tertiary border-b border-border text-xs uppercase text-text-muted">
                        <tr>
                            <th className="p-4 font-medium">Cliente</th>
                            <th className="p-4 font-medium">Stili & Idea</th>
                            <th className="p-4 font-medium">Data Richiesta</th>
                            <th className="p-4 font-medium">Stato</th>
                            <th className="p-4 font-medium text-right">Azioni</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                        {loading ? (
                            <tr><td colSpan={5} className="p-8 text-center text-text-muted">Caricamento...</td></tr>
                        ) : entries.length === 0 ? (
                            <tr><td colSpan={5} className="p-8 text-center text-text-muted">Nessuna richiesta in attesa.</td></tr>
                        ) : (
                            entries.map(entry => (
                                <tr key={entry.id} className="hover:bg-bg-tertiary/50 transition-colors group">
                                    <td className="p-4">
                                        <div className="font-medium text-white">{entry.client_name}</div>
                                        <div className="text-xs text-text-muted truncate max-w-[150px]">{entry.client_id}</div>
                                    </td>
                                    <td className="p-4">
                                        <div className="flex flex-wrap gap-1 mb-1">
                                            {entry.styles.map(s => (
                                                <span key={s} className="text-[10px] px-1.5 py-0.5 bg-accent/10 text-accent rounded border border-accent/20">{s}</span>
                                            ))}
                                        </div>
                                        <div className="text-sm text-text-secondary truncate max-w-xs" title={entry.description}>
                                            {entry.description || '-'}
                                        </div>
                                    </td>
                                    <td className="p-4 text-sm text-text-secondary">
                                        {new Date(entry.created_at).toLocaleDateString()}
                                    </td>
                                    <td className="p-4">
                                        <span className={clsx(
                                            "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium border",
                                            entry.status === 'PENDING' && "bg-yellow-500/10 text-yellow-500 border-yellow-500/20",
                                            entry.status === 'CONTACTED' && "bg-blue-500/10 text-blue-500 border-blue-500/20",
                                            entry.status === 'BOOKED' && "bg-green-500/10 text-green-500 border-green-500/20",
                                            entry.status === 'REJECTED' && "bg-red-500/10 text-red-500 border-red-500/20",
                                        )}>
                                            {entry.status === 'PENDING' && <Clock size={12} />}
                                            {entry.status === 'CONTACTED' && <UserPlus size={12} />}
                                            {entry.status === 'BOOKED' && <CheckCircle size={12} />}
                                            {entry.status === 'REJECTED' && <XCircle size={12} />}
                                            {entry.status}
                                        </span>
                                    </td>
                                    <td className="p-4 text-right">
                                        <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                            {entry.status === 'PENDING' && (
                                                <>
                                                    <button
                                                        onClick={() => handleStatusUpdate(entry.id, 'CONTACTED')}
                                                        className="p-2 bg-blue-500/10 hover:bg-blue-500/20 text-blue-500 rounded-lg transition-colors"
                                                        title="Segna come Contattato"
                                                    >
                                                        <UserPlus size={18} />
                                                    </button>
                                                    <button
                                                        onClick={() => handleStatusUpdate(entry.id, 'REJECTED')}
                                                        className="p-2 bg-red-500/10 hover:bg-red-500/20 text-red-500 rounded-lg transition-colors"
                                                        title="Rifiuta"
                                                    >
                                                        <XCircle size={18} />
                                                    </button>
                                                </>
                                            )}
                                            {entry.status === 'CONTACTED' && (
                                                <button
                                                    onClick={() => handleStatusUpdate(entry.id, 'BOOKED')}
                                                    className="p-2 bg-green-500/10 hover:bg-green-500/20 text-green-500 rounded-lg transition-colors"
                                                    title="Converti in Appuntamento"
                                                >
                                                    <CheckCircle size={18} />
                                                </button>
                                            )}
                                        </div>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
