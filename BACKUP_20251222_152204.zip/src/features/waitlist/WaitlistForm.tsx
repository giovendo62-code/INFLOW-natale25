import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { api } from '../../services/api';
import { Send, CheckCircle, AlertTriangle } from 'lucide-react';
import clsx from 'clsx';

export const WaitlistForm: React.FC = () => {
    const { studioId } = useParams<{ studioId: string }>();
    const [submitted, setSubmitted] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const [formData, setFormData] = useState({
        full_name: '',
        email: '',
        phone: '',
        fiscal_code: '',
        address: '',
        styles: [] as string[],
        artist_pref_id: '',
        description: ''
    });

    const STYLES = ['Realistico', 'Minimal', 'Old School', 'Blackwork', 'Lettering', 'Colorato', 'Geometrico'];

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError(null);
        setLoading(true);

        try {
            await api.waitlist.addToWaitlist({
                studio_id: studioId || 'studio-1',
                client_id: 'new', // Logic to handle new/existing would be backend side
                client_name: formData.full_name,
                styles: formData.styles,
                description: formData.description,
                artist_pref_id: formData.artist_pref_id
            });
            setSubmitted(true);
        } catch (err) {
            console.error(err);
            setError('Si è verificato un errore. Riprova più tardi.');
        } finally {
            setLoading(false);
        }
    };

    const toggleStyle = (style: string) => {
        setFormData(prev => ({
            ...prev,
            styles: prev.styles.includes(style)
                ? prev.styles.filter(s => s !== style)
                : [...prev.styles, style]
        }));
    };

    if (submitted) {
        return (
            <div className="min-h-screen bg-bg-primary flex items-center justify-center p-4">
                <div className="max-w-md w-full bg-bg-secondary p-8 rounded-2xl border border-accent/20 text-center">
                    <div className="w-16 h-16 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-6 text-green-500">
                        <CheckCircle size={32} />
                    </div>
                    <h2 className="text-2xl font-bold text-white mb-2">Richiesta Inviata!</h2>
                    <p className="text-text-muted">
                        Grazie per esserti iscritto alla nostra lista d'attesa. Ti contatteremo non appena si libererà un posto.
                    </p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-bg-primary py-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl mx-auto">
                <div className="text-center mb-10">
                    <h1 className="text-3xl font-bold text-white mb-2">Lista d'Attesa</h1>
                    <p className="text-text-muted">Compila il modulo per essere ricontattato.</p>
                </div>

                <form onSubmit={handleSubmit} className="bg-bg-secondary p-8 rounded-2xl border border-border shadow-xl space-y-6">
                    {/* Anagrafica */}
                    <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-white border-b border-border pb-2">Dati Personali</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="md:col-span-2">
                                <label className="block text-sm font-medium text-text-muted mb-1">Nome Completo *</label>
                                <input
                                    required
                                    type="text"
                                    value={formData.full_name}
                                    onChange={e => setFormData({ ...formData, full_name: e.target.value })}
                                    className="w-full bg-bg-tertiary border border-border rounded-lg px-4 py-3 text-white focus:border-accent focus:outline-none"
                                    placeholder="Mario Rossi"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-text-muted mb-1">Email *</label>
                                <input
                                    required
                                    type="email"
                                    value={formData.email}
                                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                                    className="w-full bg-bg-tertiary border border-border rounded-lg px-4 py-3 text-white focus:border-accent focus:outline-none"
                                    placeholder="mario@email.com"
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-text-muted mb-1">Telefono *</label>
                                <input
                                    required
                                    type="tel"
                                    value={formData.phone}
                                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                                    className="w-full bg-bg-tertiary border border-border rounded-lg px-4 py-3 text-white focus:border-accent focus:outline-none"
                                    placeholder="+39 333 1234567"
                                />
                            </div>
                        </div>
                    </div>

                    {/* Dati Fiscali */}
                    <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-white border-b border-border pb-2">Dati Fiscali (Opzionali)</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="md:col-span-2">
                                <label className="block text-sm font-medium text-text-muted mb-1">Codice Fiscale</label>
                                <input
                                    type="text"
                                    value={formData.fiscal_code}
                                    onChange={e => setFormData({ ...formData, fiscal_code: e.target.value.toUpperCase() })}
                                    className="w-full bg-bg-tertiary border border-border rounded-lg px-4 py-3 text-white focus:border-accent focus:outline-none uppercase"
                                    placeholder="RSSMRA85M01H501Z"
                                />
                            </div>
                            <div className="md:col-span-2">
                                <label className="block text-sm font-medium text-text-muted mb-1">Indirizzo Completo</label>
                                <input
                                    type="text"
                                    value={formData.address}
                                    onChange={e => setFormData({ ...formData, address: e.target.value })}
                                    className="w-full bg-bg-tertiary border border-border rounded-lg px-4 py-3 text-white focus:border-accent focus:outline-none"
                                    placeholder="Via Roma 10, Milano"
                                />
                            </div>
                        </div>
                    </div>

                    {/* Preferenze */}
                    <div className="space-y-4">
                        <h3 className="text-lg font-semibold text-white border-b border-border pb-2">Il Tuo Tatuaggio</h3>

                        <div>
                            <label className="block text-sm font-medium text-text-muted mb-2">Stile Preferito (Seleziona uno o più)</label>
                            <div className="flex flex-wrap gap-2">
                                {STYLES.map(style => (
                                    <button
                                        key={style}
                                        type="button"
                                        onClick={() => toggleStyle(style)}
                                        className={clsx(
                                            "px-4 py-2 rounded-full text-sm font-medium transition-all border",
                                            formData.styles.includes(style)
                                                ? "bg-accent text-white border-accent shadow-[0_0_10px_rgba(236,72,153,0.3)]"
                                                : "bg-bg-tertiary text-text-muted border-border hover:border-text-secondary"
                                        )}
                                    >
                                        {style}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div>
                            <label className="block text-sm font-medium text-text-muted mb-1">Descrizione Idea</label>
                            <textarea
                                rows={4}
                                value={formData.description}
                                onChange={e => setFormData({ ...formData, description: e.target.value })}
                                className="w-full bg-bg-tertiary border border-border rounded-lg px-4 py-3 text-white focus:border-accent focus:outline-none resize-none"
                                placeholder="Descrivi brevemente cosa vorresti farti tatuare e dove..."
                            />
                        </div>
                    </div>

                    {error && (
                        <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-lg flex items-center gap-2 text-red-500">
                            <AlertTriangle size={20} />
                            <span>{error}</span>
                        </div>
                    )}

                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full bg-accent hover:bg-accent-hover text-white font-bold py-4 rounded-xl transition-all shadow-[0_4px_20px_rgba(236,72,153,0.3)] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                    >
                        {loading ? 'Invio in corso...' : (
                            <>
                                <Send size={20} /> Entra in Lista d'Attesa
                            </>
                        )}
                    </button>
                </form>
            </div>
        </div>
    );
};
