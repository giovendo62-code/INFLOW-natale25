import React from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { MobileNav } from './MobileNav';

export const AppLayout: React.FC = () => {
    return (
        <div className="flex min-h-screen bg-bg-primary text-text-primary font-sans">
            <Sidebar />
            <main className="flex-1 flex flex-col min-w-0 mb-16 md:mb-0">
                <div className="flex-1 p-4 md:p-8 overflow-y-auto">
                    <Outlet />
                </div>
            </main>
            <MobileNav />
        </div>
    );
};
