import React from 'react';
import { Download, Share2, AlertTriangle, Edit2 } from 'lucide-react';
import type { MarketingCampaign } from '../../../services/types';
import { api } from '../../../services/api';

interface CampaignSummaryProps {
    data: Partial<MarketingCampaign>;
    onEdit: () => void;
}

export const CampaignSummary: React.FC<CampaignSummaryProps> = ({ data, onEdit }) => {

    // Simulate what the message looks like for a dummy user
    const previewMessage = (data.message_text || '')
        .replace('{{nome}}', 'Mario')
        .replace('{{studio_nome}}', 'InkFlow Studio')
        .replace('{{data_appuntamento}}', '25/12/2024');

    const handleCreateCampaign = async () => {
        if (!data.title || !data.message_text) return;
        try {
            await api.marketing.createCampaign({
                ...data as any,
                status: 'SENT',
                recipients_count: data.recipients_count || 0
            });
            alert('Campagna salvata nello storico!');
        } catch (e) {
            console.error(e);
            alert('Errore nel salvataggio');
        }
    };

    const handleExportCSV = () => {
        // Mock CSV Export
        const csvContent = "data:text/csv;charset=utf-8,Nome,Telefono,Messaggio\nMario Rossi,3331234567," + previewMessage;
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", `campagna_${data.title || 'export'}.csv`);
        document.body.appendChild(link);
        link.click();

        handleCreateCampaign(); // Save record when exported
    };

    return (
        <div className="max-w-4xl mx-auto space-y-8">
            <div className="bg-bg-secondary p-6 rounded-lg border border-border">
                <div className="flex justify-between items-start mb-6">
                    <div>
                        <h2 className="text-xl font-bold text-white mb-1">Riepilogo Campagna</h2>
                        <p className="text-text-muted">Controlla i dettagli prima di procedere.</p>
                    </div>
                    <button onClick={onEdit} className="text-accent hover:text-accent-hover flex items-center gap-2 text-sm font-medium">
                        <Edit2 size={16} /> Modifica
                    </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <div className="bg-bg-tertiary p-4 rounded-lg">
                        <label className="text-xs text-text-muted uppercase font-bold">Titolo</label>
                        <p className="text-white font-medium mt-1">{data.title || 'Senza titolo'}</p>
                    </div>
                    <div className="bg-bg-tertiary p-4 rounded-lg">
                        <label className="text-xs text-text-muted uppercase font-bold">Canale</label>
                        <p className="text-white font-medium mt-1">{data.channel}</p>
                    </div>
                    <div className="bg-bg-tertiary p-4 rounded-lg">
                        <label className="text-xs text-text-muted uppercase font-bold">Destinatari</label>
                        <p className="text-white font-medium mt-1">{data.recipients_count || 0} clienti selezionati</p>
                    </div>
                </div>

                <div className="border-t border-border pt-6">
                    <label className="text-xs text-text-muted uppercase font-bold mb-3 block">Anteprima Messaggio (Esempio)</label>
                    <div className="bg-[#DCF8C6] text-black p-4 rounded-lg rounded-tl-none inline-block max-w-lg shadow-sm">
                        <p className="text-sm whitespace-pre-wrap">{previewMessage}</p>
                        <span className="text-[10px] text-gray-500 block text-right mt-1">12:30</span>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Method 1: Export */}
                <div className="bg-bg-secondary p-6 rounded-lg border border-border hover:border-accent transition-colors">
                    <div className="w-12 h-12 bg-blue-500/10 rounded-full flex items-center justify-center text-blue-500 mb-4">
                        <Download size={24} />
                    </div>
                    <h3 className="text-lg font-bold text-white mb-2">Export Lista CSV</h3>
                    <p className="text-sm text-text-muted mb-6">
                        Scarica un file Excel/CSV con i contatti e i messaggi personalizzati. Ideale per importare in tool esterni o per invio manuale.
                    </p>
                    <button
                        onClick={handleExportCSV}
                        className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold transition-colors flex justify-center items-center gap-2"
                    >
                        <Download size={18} />
                        Scarica & Salva
                    </button>
                </div>

                {/* Method 2: Integration (Placeholder) */}
                <div className="bg-bg-secondary p-6 rounded-lg border border-border opacity-75">
                    <div className="w-12 h-12 bg-green-500/10 rounded-full flex items-center justify-center text-green-500 mb-4">
                        <Share2 size={24} />
                    </div>
                    <div className="flex justify-between items-start">
                        <h3 className="text-lg font-bold text-white mb-2">Invio Diretto WhatsApp</h3>
                        <span className="text-[10px] bg-red-500 text-white px-2 py-0.5 rounded font-bold">NON CONFIGURATO</span>
                    </div>
                    <p className="text-sm text-text-muted mb-6">
                        Collega WhatsApp Business API per inviare messaggi direttamente dal CRM. Richiede configurazione provider.
                    </p>
                    <button disabled className="w-full py-3 bg-bg-tertiary text-text-muted rounded-lg font-bold cursor-not-allowed flex justify-center items-center gap-2">
                        <AlertTriangle size={18} />
                        Configurazione Richiesta
                    </button>
                </div>
            </div>
        </div>
    );
};
