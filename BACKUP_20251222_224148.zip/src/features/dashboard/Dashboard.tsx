import React from 'react';
import { useAuth } from '../auth/AuthContext';
import { StatsCard } from './components/StatsCard';
import {
    DollarSign,
    Calendar,
    Users,
    UserCheck,
    Clock,
    TrendingUp,
    BookOpen
} from 'lucide-react';
import { api } from '../../services/api';
import type { ArtistContract } from '../../services/types';

export const Dashboard: React.FC = () => {
    const { user } = useAuth();

    if (!user) return null;

    const [contract, setContract] = React.useState<ArtistContract | null>(null);

    React.useEffect(() => {
        if (user.role === 'ARTIST') {
            api.artists.getContract(user.id).then(setContract).catch(console.error);
        }
    }, [user.id, user.role]);

    const renderAdminWidgets = () => (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatsCard
                title="Today's Revenue"
                value="€1,250"
                change="12%"
                isPositive={true}
                icon={DollarSign}
                color="bg-green-500"
            />
            <StatsCard
                title="Valid Appointments"
                value="8"
                change="4"
                isPositive={true}
                icon={Calendar}
                color="bg-blue-500"
            />
            <StatsCard
                title="Pending Requests"
                value="12"
                icon={Users}
                color="bg-orange-500"
            />
            <StatsCard
                title="Staff Present"
                value="5/6"
                icon={UserCheck}
                color="bg-purple-500"
            />
        </div>
    );

    const renderArtistWidgets = () => (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <StatsCard
                title="My Appointments"
                value="3"
                icon={Calendar}
                color="bg-accent"
            />
            {contract?.rent_type === 'PRESENCES' && (
                <StatsCard
                    title="Remaining Presences"
                    value={`${(contract.presence_package_limit || 0) - contract.used_presences}/${contract.presence_package_limit}`}
                    icon={Users}
                    color={(contract.presence_package_limit || 0) - contract.used_presences <= 2 ? "bg-red-500" : "bg-green-500"}
                />
            )}
            <StatsCard
                title="Next Client"
                value="in 45m"
                icon={Clock}
                color="bg-blue-500"
            />
            <StatsCard
                title="Month Revenue"
                value="€4,200"
                change="8%"
                isPositive={true}
                icon={TrendingUp}
                color="bg-green-500"
            />
        </div>
    );

    const renderStudentWidgets = () => (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <StatsCard
                title="Next Lesson"
                value="Today, 14:00"
                icon={BookOpen}
                color="bg-purple-500"
            />
            <StatsCard
                title="Attendance"
                value="92%"
                isPositive={true}
                icon={UserCheck}
                color="bg-green-500"
            />
        </div>
    );

    return (
        <div className="max-w-7xl mx-auto">
            <header className="mb-8">
                <h1 className="text-3xl font-bold text-white mb-2">
                    Welcome back, {user.full_name}
                </h1>
                <p className="text-text-muted">
                    Here's what's happening in your studio today.
                </p>
            </header>

            {/* Role Based Content */}
            {(user.role === 'STUDIO_ADMIN' || user.role === 'MANAGER') && renderAdminWidgets()}
            {user.role === 'ARTIST' && renderArtistWidgets()}
            {user.role === 'STUDENT' && renderStudentWidgets()}

            {/* Shared Recent Activity Section (Placeholder) */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-bg-secondary border border-border rounded-lg p-6 min-h-[300px]">
                    <h3 className="text-lg font-bold text-white mb-4">
                        {user.role === 'ARTIST' ? 'Today\'s Schedule' : 'Recent Activity'}
                    </h3>
                    <div className="text-text-muted text-sm flex items-center justify-center h-48 border-2 border-dashed border-border rounded-lg">
                        {user.role === 'ARTIST' ? 'Timeline View Component coming soon' : 'Activity Feed Component coming soon'}
                    </div>
                </div>

                <div className="bg-bg-secondary border border-border rounded-lg p-6 min-h-[300px]">
                    <h3 className="text-lg font-bold text-white mb-4">Quick Actions</h3>
                    <div className="space-y-3">
                        <button className="w-full py-3 px-4 bg-accent hover:bg-accent-hover text-white rounded-lg font-medium transition-colors">
                            + New Appointment
                        </button>
                        <button className="w-full py-3 px-4 bg-bg-tertiary hover:bg-white/10 text-text-primary rounded-lg font-medium transition-colors border border-border">
                            Check Messages
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};
