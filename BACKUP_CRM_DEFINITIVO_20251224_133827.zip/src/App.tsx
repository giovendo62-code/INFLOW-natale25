// import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './features/auth/AuthContext';
import { RoleGuard } from './features/auth/RoleGuard';
import { AppLayout } from './components/AppLayout';
import { LoginPage } from './features/auth/LoginPage';
import {
    DashboardPage,
    CalendarPage,
    ClientsPage,
    ClientProfilePage,
    FinancialsPage,
    AcademyPage,
    ChatPage,
    SettingsPage,
    ConsentsPage
} from './components/Placeholders';
import { ArtistsPage } from './features/artists/ArtistsPage';
import { ArtistProfilePage } from './features/artists/ArtistProfilePage';
import { MarketingPage } from './features/marketing/MarketingPage';
import { WaitlistManager } from './features/waitlist/WaitlistManager';
import { CommunicationsPage } from './features/communications/CommunicationsPage';
import { WaitlistForm } from './features/waitlist/WaitlistForm';
import { PublicClientForm } from './features/clients/PublicClientForm';

function App() {
    return (
        <AuthProvider>
            <BrowserRouter>
                <Routes>
                    <Route path="/login" element={<LoginPage />} />

                    {/* Public Routes */}
                    <Route path="/public/waitlist/:studioId" element={<WaitlistForm />} />
                    <Route path="/public/register/:studioId" element={<PublicClientForm />} />

                    <Route element={<RoleGuard />}>
                        <Route element={<AppLayout />}>
                            <Route path="/" element={<DashboardPage />} />

                            <Route element={<RoleGuard allowedRoles={['STUDIO_ADMIN', 'MANAGER', 'ARTIST']} />}>
                                <Route path="/calendar" element={<CalendarPage />} />
                                <Route path="/clients" element={<ClientsPage />} />
                                <Route path="/clients/:id" element={<ClientProfilePage />} />
                                <Route path="/consents" element={<ConsentsPage />} />
                                <Route path="/chat" element={<ChatPage />} />
                                <Route path="/financials" element={<FinancialsPage />} />
                            </Route>

                            <Route element={<RoleGuard allowedRoles={['STUDIO_ADMIN', 'MANAGER', 'ARTIST']} />}>
                                <Route path="/communications" element={<CommunicationsPage />} />
                            </Route>
                            <Route element={<RoleGuard allowedRoles={['STUDIO_ADMIN', 'MANAGER']} />}>
                                <Route path="/waitlist" element={<WaitlistManager />} />
                                <Route path="/artists" element={<ArtistsPage />} />
                                <Route path="/artists/:id" element={<ArtistProfilePage />} />
                                <Route path="/marketing" element={<MarketingPage />} />
                                <Route path="/settings" element={<SettingsPage />} />
                            </Route>

                            <Route element={<RoleGuard allowedRoles={['STUDIO_ADMIN', 'STUDENT']} />}>
                                <Route path="/academy" element={<AcademyPage />} />
                            </Route>

                        </Route>
                    </Route>

                    {/* Catch all - Redirect to Dashboard if logged in, else Login */}
                    <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
            </BrowserRouter>
        </AuthProvider>
    );
}

export default App;
