import React, { useState, useEffect } from 'react';
import { BookOpen, FileText, Plus, Users, Minus, Clock, DollarSign, X, ChevronRight, RefreshCw, Trash2, PlayCircle } from 'lucide-react';
import { api } from '../../services/api';
import type { Course, CourseMaterial, CourseEnrollment, AttendanceLog } from '../../services/types';
import clsx from 'clsx';

export const AcademyPage: React.FC = () => {
    const [courses, setCourses] = useState<Course[]>([]);
    const [loading, setLoading] = useState(true);
    const [view, setView] = useState<'LIST' | 'CREATE' | 'MANAGE'>('LIST');
    const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);

    // Form State
    const [newCourse, setNewCourse] = useState<Partial<Course>>({
        title: '',
        description: '',
        duration: '',
        materials: [],
        student_ids: []
    });

    // Manage State
    const [activeTab, setActiveTab] = useState<'INFO' | 'MATERIALS' | 'STUDENTS' | 'ATTENDANCE'>('INFO');

    // Attendance Detailed State
    const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);
    const [studentEnrollment, setStudentEnrollment] = useState<CourseEnrollment | null>(null);
    const [_attendanceLogs, setAttendanceLogs] = useState<AttendanceLog[]>([]);
    const [loadingEnrollment, setLoadingEnrollment] = useState(false);
    // const [attendanceDate] = useState<string>(new Date().toISOString().split('T')[0]);

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        setLoading(true);
        try {
            const data = await api.academy.listCourses();
            setCourses(data);
        } finally {
            setLoading(false);
        }
    };

    const handleCreateCourse = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            if (!newCourse.title || !newCourse.duration) return;

            await api.academy.createCourse({
                title: newCourse.title,
                description: newCourse.description || '',
                duration: newCourse.duration,
                materials: [],
                student_ids: []
            });

            await loadData();
            setView('LIST');
            setNewCourse({ title: '', description: '', duration: '', materials: [], student_ids: [] });
        } catch (error) {
            console.error(error);
        }
    };

    const handleManageCourse = (course: Course) => {
        setSelectedCourse(course);
        setView('MANAGE');
        setActiveTab('INFO');
    };

    const handleUpdateCourse = async (updates: Partial<Course>) => {
        if (!selectedCourse) return;
        try {
            const updated = await api.academy.updateCourse(selectedCourse.id, updates);
            setSelectedCourse(updated);

            // Update local list
            setCourses(courses.map(c => c.id === updated.id ? updated : c));
        } catch (error) {
            console.error(error);
        }
    };

    const handleAddMaterial = async () => {
        const title = prompt("Titolo del materiale:");
        if (!title) return;

        const newMaterial: CourseMaterial = {
            id: `mat-${Date.now()}`,
            title,
            type: 'PDF',
            url: '#'
        };

        await handleUpdateCourse({
            materials: [...(selectedCourse?.materials || []), newMaterial]
        });
    };

    /* const handleAddStudent = async () => {
        const studentId = prompt("ID dello studente (es. user-student):");
        if (!studentId) return;
        if (selectedCourse?.student_ids.includes(studentId)) {
            alert("Studente già iscritto");
            return;
        }

        await handleUpdateCourse({
            student_ids: [...(selectedCourse?.student_ids || []), studentId]
        });
    }; */

    const handleAddStudent = async () => {
        const studentId = prompt("Inserisci l'ID o l'Email dello studente da aggiungere:");
        if (!studentId) return;

        // In a real scenario, we should verify the user exists here.
        // For now, we allow adding the ID.
        if (selectedCourse?.student_ids.includes(studentId)) {
            alert("Studente già iscritto");
            return;
        }

        await handleUpdateCourse({
            student_ids: [...(selectedCourse?.student_ids || []), studentId]
        });
    };





    // Detailed Attendance Logic
    const fetchEnrollmentData = async (studentId: string) => {
        if (!selectedCourse) return;
        setLoadingEnrollment(true);
        try {
            const enroll = await api.academy.getEnrollment(selectedCourse.id, studentId);
            setStudentEnrollment(enroll);
            // Logs removed from UI, but data fetch kept if needed for other logic or simplified view
            // const logs = await api.academy.getAttendanceLogs(selectedCourse.id, studentId);
            // setAttendanceLogs(logs);
        } catch (error) {
            console.error(error);
        } finally {
            setLoadingEnrollment(false);
        }
    };

    const handleSelectStudentForAttendance = (studentId: string) => {
        setSelectedStudentId(studentId);
        fetchEnrollmentData(studentId);
    };

    const handleUpdateAttendanceCount = async (delta: number) => {
        if (!selectedCourse || !selectedStudentId || !studentEnrollment) return;

        const newAttended = studentEnrollment.attended_days + delta;
        if (newAttended < 0) {
            alert("Non puoi scendere sotto 0 presenze.");
            return;
        }
        if (newAttended > studentEnrollment.allowed_days) {
            alert("Hai raggiunto il limite di giorni frequentabili.");
            return;
        }

        try {
            const updated = await api.academy.updateEnrollment(selectedCourse.id, selectedStudentId, {
                attended_days: newAttended,
                attendance_updated_at: new Date().toISOString()
            });
            setStudentEnrollment(updated);

            // Log
            await api.academy.logAttendance({
                course_id: selectedCourse.id,
                student_id: selectedStudentId,
                action: delta > 0 ? 'INCREMENT' : 'DECREMENT',
                previous_value: studentEnrollment.attended_days,
                new_value: newAttended,
                created_by: 'current-user' // Should come from auth context
            });

            // Refresh logs
            const logs = await api.academy.getAttendanceLogs(selectedCourse.id, selectedStudentId);
            setAttendanceLogs(logs);

        } catch (error) {
            console.error(error);
        }
    };

    const handleSetAttendanceCount = async (value: number) => {
        if (!selectedCourse || !selectedStudentId || !studentEnrollment) return;
        if (value < 0 || value > studentEnrollment.allowed_days) {
            alert("Valore non valido (fuori dai limiti).");
            return;
        }

        const prev = studentEnrollment.attended_days;
        try {
            const updated = await api.academy.updateEnrollment(selectedCourse.id, selectedStudentId, {
                attended_days: value,
                attendance_updated_at: new Date().toISOString()
            });
            setStudentEnrollment(updated);

            await api.academy.logAttendance({
                course_id: selectedCourse.id,
                student_id: selectedStudentId,
                action: value === 0 ? 'RESET' : 'SET',
                previous_value: prev,
                new_value: value,
                created_by: 'current-user'
            });
            const logs = await api.academy.getAttendanceLogs(selectedCourse.id, selectedStudentId);
            setAttendanceLogs(logs);
        } catch (error) {
            console.error(error);
        }
    };

    const handleUpdateAllowedDays = async (newLimit: number) => {
        if (!selectedCourse || !selectedStudentId || !studentEnrollment) return;
        if (newLimit < 0) return;

        let newAttended = studentEnrollment.attended_days;


        if (newLimit < newAttended) {
            newAttended = newLimit;
            alert("Attenzione: il nuovo limite è inferiore alle presenze attuali. Le presenze sono state riallineate.");
        }

        try {
            const updated = await api.academy.updateEnrollment(selectedCourse.id, selectedStudentId, {
                allowed_days: newLimit,
                attended_days: newAttended, // Autosync if needed
                attendance_updated_at: new Date().toISOString()
            });
            setStudentEnrollment(updated);

            await api.academy.logAttendance({
                course_id: selectedCourse.id,
                student_id: selectedStudentId,
                action: 'LIMIT_CHANGE',
                previous_value: studentEnrollment.allowed_days,
                new_value: newLimit,
                created_by: 'current-user'
            });

            const logs = await api.academy.getAttendanceLogs(selectedCourse.id, selectedStudentId);
            setAttendanceLogs(logs);

        } catch (error) {
            console.error(error);
        }
    };

    const handleDeleteCourse = async () => {
        if (!selectedCourse) return;
        if (!confirm("Sei sicuro di voler eliminare questo corso? L'azione è irreversibile.")) return;

        try {
            await api.academy.deleteCourse(selectedCourse.id);
            await loadData();
            setView('LIST');
            setSelectedCourse(null);
        } catch (error) {
            console.error(error);
            alert("Errore durante l'eliminazione del corso.");
        }
    };

    return (
        <div className="space-y-8 h-full flex flex-col">
            {/* Header */}
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-white">Academy</h1>
                    <p className="text-text-muted">Gestione corsi, materiali e studenti.</p>
                </div>
                {view === 'LIST' && (
                    <button
                        onClick={() => setView('CREATE')}
                        className="flex items-center gap-2 bg-accent hover:bg-accent-hover text-white px-4 py-2 rounded-lg font-bold transition-colors"
                    >
                        <Plus size={20} /> Nuovo Corso
                    </button>
                )}
                {view !== 'LIST' && (
                    <button
                        onClick={() => setView('LIST')}
                        className="flex items-center gap-2 bg-bg-tertiary hover:bg-white/10 text-white px-4 py-2 rounded-lg font-bold transition-colors border border-border"
                    >
                        Indietro
                    </button>
                )}
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto">
                {view === 'LIST' ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {loading ? (
                            <div className="col-span-full text-center text-text-muted py-12">Caricamento corsi...</div>
                        ) : courses.map(course => (
                            <div key={course.id} className="bg-bg-secondary border border-border rounded-xl overflow-hidden hover:border-accent/50 transition-all group flex flex-col">
                                <div className="p-6 flex-1">
                                    <div className="flex justify-between items-start mb-4">
                                        <div className="p-3 bg-bg-tertiary rounded-lg text-accent">
                                            <BookOpen size={24} />
                                        </div>
                                        <span className="text-xs font-medium px-2 py-1 bg-bg-tertiary rounded text-text-muted">
                                            {course.duration}
                                        </span>
                                    </div>
                                    <h3 className="text-xl font-bold text-white mb-2">{course.title}</h3>
                                    <p className="text-sm text-text-secondary line-clamp-3 mb-4">
                                        {course.description}
                                    </p>

                                    <div className="flex items-center gap-4 text-sm text-text-muted mt-auto pt-4 border-t border-border">
                                        <div className="flex items-center gap-1">
                                            <FileText size={16} />
                                            <span>{course.materials?.length || 0} Moduli</span>
                                        </div>
                                        <div className="flex items-center gap-1">
                                            <Users size={16} />
                                            <span>{course.student_ids?.length || 0} Studenti</span>
                                        </div>
                                    </div>
                                </div>
                                <div className="bg-bg-tertiary/50 p-4 border-t border-border">
                                    <button
                                        onClick={() => handleManageCourse(course)}
                                        className="w-full py-2 bg-white/5 hover:bg-white/10 text-white rounded-lg transition-colors text-sm font-medium"
                                    >
                                        Gestisci Corso
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : view === 'MANAGE' && selectedCourse ? (
                    <div className="bg-bg-secondary rounded-xl border border-border overflow-hidden shadow-2xl">
                        {/* Course Header */}
                        <div className="p-8 border-b border-border bg-bg-tertiary/20">
                            <div className="flex justify-between items-start">
                                <div>
                                    <h2 className="text-3xl font-bold text-white mb-2">{selectedCourse.title}</h2>
                                    <p className="text-text-muted">{selectedCourse.description}</p>
                                </div>
                                <button
                                    onClick={handleDeleteCourse}
                                    className="p-2 text-red-500 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                                    title="Elimina Corso"
                                >
                                    <Trash2 size={24} />
                                </button>
                            </div>

                            <div className="flex gap-4 mt-6 overflow-x-auto pb-2">
                                <button
                                    onClick={() => setActiveTab('INFO')}
                                    className={clsx("px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap", activeTab === 'INFO' ? "bg-accent text-white shadow-lg shadow-accent/20" : "text-text-secondary hover:text-white")}
                                >
                                    Info Gen.
                                </button>
                                <button
                                    onClick={() => setActiveTab('MATERIALS')}
                                    className={clsx("px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap", activeTab === 'MATERIALS' ? "bg-accent text-white shadow-lg shadow-accent/20" : "text-text-secondary hover:text-white")}
                                >
                                    Materiale Didattico
                                </button>
                                <button
                                    onClick={() => setActiveTab('STUDENTS')}
                                    className={clsx("px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap", activeTab === 'STUDENTS' ? "bg-accent text-white shadow-lg shadow-accent/20" : "text-text-secondary hover:text-white")}
                                >
                                    Corsisti
                                </button>
                                <button
                                    onClick={() => setActiveTab('ATTENDANCE')}
                                    className={clsx("px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap", activeTab === 'ATTENDANCE' ? "bg-accent text-white shadow-lg shadow-accent/20" : "text-text-secondary hover:text-white")}
                                >
                                    Registro
                                </button>
                            </div>
                        </div>

                        <div className="p-8">
                            {/* INFO TAB */}
                            {activeTab === 'INFO' && (
                                <div className="space-y-6 max-w-2xl">
                                    <div>
                                        <label className="block text-sm font-medium text-text-secondary mb-2">Titolo Corso</label>
                                        <input
                                            type="text"
                                            className="w-full bg-bg-tertiary border border-border rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-accent outline-none"
                                            value={selectedCourse.title}
                                            onChange={(e) => handleUpdateCourse({ title: e.target.value })}
                                        />
                                    </div>
                                    <div className="grid grid-cols-2 gap-6">
                                        <div>
                                            <label className="block text-sm font-medium text-text-secondary mb-2">Durata</label>
                                            <input
                                                type="text"
                                                className="w-full bg-bg-tertiary border border-border rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-accent outline-none"
                                                value={selectedCourse.duration}
                                                onChange={(e) => handleUpdateCourse({ duration: e.target.value })}
                                            />
                                        </div>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-text-secondary mb-2">Descrizione</label>
                                        <textarea
                                            className="w-full bg-bg-tertiary border border-border rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-accent outline-none h-32 resize-none"
                                            value={selectedCourse.description}
                                            onChange={(e) => handleUpdateCourse({ description: e.target.value })}
                                        />
                                    </div>
                                </div>
                            )}

                            {/* MATERIALS TAB */}
                            {activeTab === 'MATERIALS' && (
                                <div>
                                    <div className="flex justify-between items-center mb-6">
                                        <h3 className="text-xl font-bold text-white">Materiali Didattici</h3>
                                        <button
                                            onClick={handleAddMaterial}
                                            className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg font-medium transition-colors"
                                        >
                                            <Plus size={18} /> Aggiungi Materiale
                                        </button>
                                    </div>

                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                        {(selectedCourse.materials || []).length === 0 && (
                                            <p className="col-span-full text-text-muted italic">Nessun materiale caricato.</p>
                                        )}
                                        {(selectedCourse.materials || []).map((mat, idx) => (
                                            <div key={idx} className="bg-bg-tertiary p-4 rounded-lg border border-border flex items-center gap-4">
                                                <div className="p-2 bg-bg-secondary rounded text-accent">
                                                    {mat.type === 'VIDEO' ? <PlayCircle size={20} /> : <FileText size={20} />}
                                                </div>
                                                <div className="flex-1 overflow-hidden">
                                                    <p className="text-white font-medium truncate">{mat.title}</p>
                                                    <p className="text-xs text-text-muted">{mat.type}</p>
                                                </div>
                                                <button className="text-red-400 hover:text-red-300 transition-colors">
                                                    <X size={18} />
                                                </button>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {/* STUDENTS TAB */}
                            {activeTab === 'STUDENTS' && (
                                <div>
                                    <div className="flex justify-between items-center mb-6">
                                        <h3 className="text-xl font-bold text-white">Corsisti Iscritti</h3>
                                        <button
                                            onClick={handleAddStudent}
                                            className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg font-medium transition-colors"
                                        >
                                            <Users size={18} /> Aggiungi Studente
                                        </button>
                                    </div>

                                    <div className="space-y-2">
                                        {(selectedCourse.student_ids || []).length === 0 && (
                                            <p className="text-text-muted italic">Nessun studente iscritto.</p>
                                        )}
                                        {(selectedCourse.student_ids || []).map((sid, idx) => (
                                            <div key={idx} className="flex items-center justify-between p-4 bg-bg-tertiary rounded-lg border border-border">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center text-accent font-bold">
                                                        {sid.substring(0, 2).toUpperCase()}
                                                    </div>
                                                    <div>
                                                        <p className="text-white font-medium">Studente ID: {sid}</p>
                                                        <p className="text-xs text-text-muted">Iscritto</p>
                                                    </div>
                                                </div>
                                                <button className="text-text-muted hover:text-white px-3 py-1 rounded bg-bg-secondary border border-border">
                                                    Rimuovi
                                                </button>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {/* ATTENDANCE TAB */}
                            {activeTab === 'ATTENDANCE' && (
                                <div className="h-[600px] flex flex-col">
                                    {selectedStudentId ? (
                                        // Detail View
                                        <div className="flex-1 overflow-y-auto pr-2">
                                            <button
                                                onClick={() => setSelectedStudentId(null)}
                                                className="flex items-center gap-2 text-text-secondary hover:text-white mb-6 transition-colors"
                                            >
                                                <ChevronRight className="rotate-180" size={20} /> Torna alla lista
                                            </button>

                                            {loadingEnrollment || !studentEnrollment ? (
                                                <div className="text-center py-12 text-text-muted">Caricamento dati studente...</div>
                                            ) : (
                                                <div className="space-y-8">
                                                    {/* Header Card */}
                                                    <div className="bg-bg-tertiary p-6 rounded-xl border border-border flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                                                        <div>
                                                            <h3 className="text-2xl font-bold text-white mb-1">Studente: {selectedStudentId}</h3>
                                                            <p className="text-text-muted">Gestione presenze e permessi per questo corso.</p>
                                                        </div>
                                                        <div className="flex flex-col items-end">
                                                            <span className={clsx("px-3 py-1 rounded text-sm font-bold border",
                                                                studentEnrollment.attended_days >= studentEnrollment.allowed_days
                                                                    ? "bg-red-500/10 text-red-500 border-red-500/20"
                                                                    : "bg-green-500/10 text-green-500 border-green-500/20")}>
                                                                {studentEnrollment.attended_days >= studentEnrollment.allowed_days ? "LIMITE RAGGIUNTO" : "STATO REGOLARE"}
                                                            </span>
                                                        </div>
                                                    </div>

                                                    {/* Stats & Progress */}
                                                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                                                        {/* Progress Card */}
                                                        <div className="lg:col-span-2 bg-bg-tertiary p-6 rounded-xl border border-border">
                                                            <h4 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                                                                <Clock size={20} className="text-accent" /> Progresso Presenze
                                                            </h4>

                                                            <div className="mb-2 flex justify-between items-end">
                                                                <span className="text-4xl font-bold text-white">{studentEnrollment.attended_days}</span>
                                                                <span className="text-xl text-text-muted mb-1">/ {studentEnrollment.allowed_days} giorni</span>
                                                            </div>

                                                            <div className="w-full bg-bg-secondary h-4 rounded-full overflow-hidden mb-6">
                                                                <div
                                                                    className={clsx("h-full transition-all duration-500",
                                                                        studentEnrollment.attended_days >= studentEnrollment.allowed_days ? "bg-red-500" : "bg-accent")}
                                                                    style={{ width: `${Math.min((studentEnrollment.attended_days / studentEnrollment.allowed_days) * 100, 100)}%` }}
                                                                />
                                                            </div>

                                                            <div className="flex flex-wrap gap-3">
                                                                <button
                                                                    onClick={() => handleUpdateAttendanceCount(1)}
                                                                    disabled={studentEnrollment.attended_days >= studentEnrollment.allowed_days}
                                                                    className="flex-1 py-3 bg-green-500/20 hover:bg-green-500/30 text-green-400 rounded-lg font-bold border border-green-500/20 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                                                                >
                                                                    <Plus size={20} /> Aggiungi Giorno
                                                                </button>
                                                                <button
                                                                    onClick={() => handleUpdateAttendanceCount(-1)}
                                                                    disabled={studentEnrollment.attended_days <= 0}
                                                                    className="flex-1 py-3 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg font-bold border border-red-500/20 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                                                                >
                                                                    <Minus size={20} /> Rimuovi Giorno
                                                                </button>
                                                            </div>
                                                        </div>

                                                        {/* Settings Card */}
                                                        <div className="bg-bg-tertiary p-6 rounded-xl border border-border space-y-6">
                                                            <h4 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                                                                <Users size={20} className="text-accent" /> Impostazioni
                                                            </h4>

                                                            <div>
                                                                <label className="block text-sm font-medium text-text-secondary mb-2">Totale Giorni Frequentabili</label>
                                                                <div className="flex gap-2">
                                                                    <input
                                                                        type="number"
                                                                        className="w-full bg-bg-secondary border border-border rounded px-3 py-2 text-white outline-none focus:border-accent"
                                                                        value={studentEnrollment.allowed_days}
                                                                        onChange={(e) => handleUpdateAllowedDays(parseInt(e.target.value) || 0)}
                                                                    />
                                                                </div>
                                                                <p className="text-xs text-text-muted mt-2">
                                                                    Modificare questo valore ricalcolerà le percentuali. Se ridotto sotto le presenze attuali, queste verranno tagliate.
                                                                </p>
                                                            </div>

                                                            <div className="pt-4 border-t border-border">
                                                                <button
                                                                    onClick={() => {
                                                                        if (confirm("Sei sicuro di voler resettare a 0 le presenze?")) handleSetAttendanceCount(0);
                                                                    }}
                                                                    className="w-full py-2 bg-white/5 hover:bg-red-500/20 hover:text-red-400 text-text-secondary rounded-lg transition-colors text-sm font-medium flex items-center justify-center gap-2"
                                                                >
                                                                    <RefreshCw size={16} /> Reset Totale Presenze
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    {/* Financial Management Card */}
                                                    <div className="bg-bg-tertiary p-6 rounded-xl border border-border">
                                                        <h4 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                                                            <DollarSign size={20} className="text-accent" /> Gestione Pagamenti
                                                        </h4>

                                                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                                                            <div>
                                                                <label className="block text-sm font-medium text-text-secondary mb-2">Costo Totale Corso (€)</label>
                                                                <input
                                                                    type="number"
                                                                    className="w-full bg-bg-secondary border border-border rounded-lg px-3 py-2 text-white outline-none focus:border-accent"
                                                                    placeholder="0.00"
                                                                    value={studentEnrollment.total_cost || ''}
                                                                    onChange={async (e) => {
                                                                        const val = parseFloat(e.target.value);
                                                                        const updated = await api.academy.updateEnrollment(selectedCourse.id, selectedStudentId!, {
                                                                            total_cost: isNaN(val) ? 0 : val
                                                                        });
                                                                        setStudentEnrollment(updated);
                                                                    }}
                                                                />
                                                            </div>
                                                            <div>
                                                                <label className="block text-sm font-medium text-text-secondary mb-2">Totale Versato</label>
                                                                <div className="px-3 py-2 bg-bg-secondary/50 border border-border rounded-lg text-white font-bold">
                                                                    € {studentEnrollment.deposits?.reduce((acc, curr) => acc + curr.amount, 0).toFixed(2) || '0.00'}
                                                                </div>
                                                            </div>
                                                            <div>
                                                                <label className="block text-sm font-medium text-text-secondary mb-2">Saldo Residuo</label>
                                                                <div className={clsx("px-3 py-2 bg-bg-secondary/50 border border-border rounded-lg font-bold",
                                                                    (studentEnrollment.total_cost || 0) - (studentEnrollment.deposits?.reduce((acc, curr) => acc + curr.amount, 0) || 0) > 0 ? "text-red-400" : "text-green-400"
                                                                )}>
                                                                    € {((studentEnrollment.total_cost || 0) - (studentEnrollment.deposits?.reduce((acc, curr) => acc + curr.amount, 0) || 0)).toFixed(2)}
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div className="mb-4">
                                                            <div className="flex justify-between items-center mb-2">
                                                                <h5 className="font-medium text-text-secondary">Storico Acconti</h5>
                                                                <button
                                                                    onClick={async () => {
                                                                        const amount = parseFloat(prompt("Importo acconto (€):") || "0");
                                                                        if (!amount || amount <= 0) return;
                                                                        const note = prompt("Nota (opzionale):") || "";

                                                                        const newDeposit = {
                                                                            id: `dep-${Date.now()}`,
                                                                            amount,
                                                                            date: new Date().toISOString(),
                                                                            note
                                                                        };

                                                                        const updated = await api.academy.updateEnrollment(selectedCourse.id, selectedStudentId!, {
                                                                            deposits: [...(studentEnrollment.deposits || []), newDeposit]
                                                                        });
                                                                        setStudentEnrollment(updated);
                                                                    }}
                                                                    className="text-sm text-accent hover:text-accent-hover flex items-center gap-1"
                                                                >
                                                                    <Plus size={16} /> Aggiungi Acconto
                                                                </button>
                                                            </div>

                                                            <div className="bg-bg-secondary rounded-lg border border-border overflow-hidden">
                                                                <table className="w-full text-left text-sm">
                                                                    <thead className="bg-white/5 text-text-muted">
                                                                        <tr>
                                                                            <th className="p-3">Data</th>
                                                                            <th className="p-3">Nota</th>
                                                                            <th className="p-3 text-right">Importo</th>
                                                                            <th className="p-3 text-right">Azioni</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody className="divide-y divide-border/30">
                                                                        {(studentEnrollment.deposits || []).length === 0 && (
                                                                            <tr>
                                                                                <td colSpan={4} className="p-4 text-center text-text-muted italic">Nessun acconto registrato.</td>
                                                                            </tr>
                                                                        )}
                                                                        {(studentEnrollment.deposits || []).map((dep) => (
                                                                            <tr key={dep.id} className="hover:bg-white/5">
                                                                                <td className="p-3 text-white">{new Date(dep.date).toLocaleDateString()}</td>
                                                                                <td className="p-3 text-text-secondary">{dep.note || '-'}</td>
                                                                                <td className="p-3 text-right font-medium text-white">€ {dep.amount.toFixed(2)}</td>
                                                                                <td className="p-3 text-right">
                                                                                    <button
                                                                                        onClick={async () => {
                                                                                            if (!confirm("Eliminare questo acconto?")) return;
                                                                                            const updatedDeposits = studentEnrollment.deposits?.filter(d => d.id !== dep.id) || [];
                                                                                            const updated = await api.academy.updateEnrollment(selectedCourse.id, selectedStudentId!, {
                                                                                                deposits: updatedDeposits
                                                                                            });
                                                                                            setStudentEnrollment(updated);
                                                                                        }}
                                                                                        className="text-red-400 hover:text-red-300 p-1 rounded hover:bg-red-400/10"
                                                                                    >
                                                                                        <X size={14} />
                                                                                    </button>
                                                                                </td>
                                                                            </tr>
                                                                        ))}
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    {/* History Log Removed as per request */}
                                                </div>
                                            )}
                                        </div>
                                    ) : (
                                        // List View
                                        <div className="flex-1 flex flex-col">
                                            <div className="flex justify-between items-center mb-6">
                                                <div>
                                                    <h3 className="text-xl font-bold text-white">Registro Presenze</h3>
                                                    <p className="text-text-muted text-sm">Seleziona uno studente per visualizzare i dettagli completi.</p>
                                                </div>
                                            </div>

                                            <div className="bg-bg-tertiary/20 rounded-lg border border-border overflow-hidden">
                                                <table className="w-full text-left">
                                                    <thead className="bg-bg-tertiary border-b border-border">
                                                        <tr>
                                                            <th className="p-4 font-medium text-text-muted">Studente</th>
                                                            <th className="p-4 font-medium text-text-muted text-center">Azioni Rapide</th>
                                                            <th className="p-4 font-medium text-text-muted text-right">Gestisci</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody className="divide-y divide-border/50">
                                                        {(selectedCourse.student_ids || []).length === 0 && (
                                                            <tr>
                                                                <td colSpan={3} className="p-6 text-center text-text-muted italic">
                                                                    Nessun studente iscritto al corso.
                                                                </td>
                                                            </tr>
                                                        )}
                                                        {(selectedCourse.student_ids || []).map((sid) => (
                                                            <tr key={sid} className="group hover:bg-white/5 transition-colors">
                                                                <td className="p-4">
                                                                    <div className="flex items-center gap-3">
                                                                        <div className="w-8 h-8 rounded-full bg-purple-500/20 text-purple-400 flex items-center justify-center text-xs font-bold">
                                                                            {sid.substring(0, 2).toUpperCase()}
                                                                        </div>
                                                                        <div>
                                                                            <p className="text-white font-medium">{sid}</p>
                                                                        </div>
                                                                    </div>
                                                                </td>
                                                                <td className="p-4">
                                                                    <div className="flex items-center justify-center gap-2">
                                                                        {/* Quick Mark buttons could go here if still desired, or removed to focus on detail view */}
                                                                        <span className="text-xs text-text-muted">Clicca Dettagli per gestire</span>
                                                                    </div>
                                                                </td>
                                                                <td className="p-4 text-right">
                                                                    <button
                                                                        onClick={() => handleSelectStudentForAttendance(sid)}
                                                                        className="px-3 py-1.5 bg-accent/10 hover:bg-accent/20 text-accent border border-accent/20 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ml-auto"
                                                                    >
                                                                        Dettagli <ChevronRight size={16} />
                                                                    </button>
                                                                </td>
                                                            </tr>
                                                        ))}
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            )}
                        </div>
                    </div>
                ) : (
                    /* Create Form */
                    <div className="max-w-2xl mx-auto bg-bg-secondary p-8 rounded-xl border border-border">
                        <h2 className="text-xl font-bold text-white mb-6">Crea Nuovo Corso</h2>
                        <form onSubmit={handleCreateCourse} className="space-y-6">
                            <div>
                                <label className="block text-sm font-medium text-text-secondary mb-2">Titolo Corso</label>
                                <input
                                    type="text"
                                    required
                                    className="w-full bg-bg-tertiary border border-border rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-accent outline-none"
                                    placeholder="es. Masterclass Realistico"
                                    value={newCourse.title}
                                    onChange={e => setNewCourse({ ...newCourse, title: e.target.value })}
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-6">
                                <div>
                                    <label className="block text-sm font-medium text-text-secondary mb-2">Durata</label>
                                    <div className="relative">
                                        <input
                                            type="text"
                                            required
                                            className="w-full bg-bg-tertiary border border-border rounded-lg pl-10 pr-4 py-3 text-white focus:ring-2 focus:ring-accent outline-none"
                                            placeholder="es. 3 Mesi"
                                            value={newCourse.duration}
                                            onChange={e => setNewCourse({ ...newCourse, duration: e.target.value })}
                                        />
                                        <Clock className="absolute left-3 top-3.5 text-text-muted" size={18} />
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-text-secondary mb-2">Costo (Opzionale)</label>
                                    <div className="relative">
                                        <input
                                            type="number"
                                            className="w-full bg-bg-tertiary border border-border rounded-lg pl-10 pr-4 py-3 text-white focus:ring-2 focus:ring-accent outline-none"
                                            placeholder="0.00"
                                        />
                                        <DollarSign className="absolute left-3 top-3.5 text-text-muted" size={18} />
                                    </div>
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-text-secondary mb-2">Descrizione</label>
                                <textarea
                                    className="w-full bg-bg-tertiary border border-border rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-accent outline-none h-32 resize-none"
                                    placeholder="Descrivi gli obiettivi e il programma del corso..."
                                    value={newCourse.description}
                                    onChange={e => setNewCourse({ ...newCourse, description: e.target.value })}
                                />
                            </div>

                            {/* Section for Materials & Students could go here */}
                            <div className="p-4 bg-bg-tertiary/50 rounded-lg border border-border border-dashed text-center">
                                <p className="text-sm text-text-muted">Potrai aggiungere materiali didattici e assegnare studenti dopo aver creato il corso.</p>
                            </div>

                            <div className="flex justify-end gap-3 pt-4">
                                <button
                                    type="button"
                                    onClick={() => setView('LIST')}
                                    className="px-6 py-2 text-text-secondary hover:text-white transition-colors"
                                >
                                    Annulla
                                </button>
                                <button
                                    type="submit"
                                    className="px-8 py-2 bg-accent hover:bg-accent-hover text-white rounded-lg font-bold transition-all shadow-lg shadow-accent/20"
                                >
                                    Crea Corso
                                </button>
                            </div>
                        </form>
                    </div>
                )}
            </div>
        </div>
    );
};
