import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Filter, User as UserIcon, AlertCircle, Plus, MessageCircle } from 'lucide-react';
import { api } from '../../services/api';
import { useAuth } from '../auth/AuthContext';
import type { User, ArtistContract } from '../../services/types';

export const ArtistsPage: React.FC = () => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const [artists, setArtists] = useState<User[]>([]);
    const [contracts, setContracts] = useState<Record<string, ArtistContract | null>>({});
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');

    const [showAddModal, setShowAddModal] = useState(false);
    const [newArtistEmail, setNewArtistEmail] = useState('');
    const [adding, setAdding] = useState(false);

    useEffect(() => {
        loadData();
    }, [user?.studio_id]);

    const loadData = async () => {
        if (!user?.studio_id) return;
        try {
            const artistsList = await api.artists.list(user.studio_id);
            setArtists(artistsList);

            // Load contracts for all artists
            const contractsMap: Record<string, ArtistContract | null> = {};
            await Promise.all(artistsList.map(async (a) => {
                const c = await api.artists.getContract(a.id);
                contractsMap[a.id] = c;
            }));
            setContracts(contractsMap);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    const handleAddArtist = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!user?.studio_id || !newArtistEmail) return;

        setAdding(true);
        try {
            // Use inviteMember to create the artist user
            await api.settings.inviteMember(newArtistEmail, 'ARTIST', user.studio_id);

            // Refresh list
            await loadData();
            setShowAddModal(false);
            setNewArtistEmail('');
        } catch (err) {
            alert('Failed to add artist');
            console.error(err);
        } finally {
            setAdding(false);
        }
    };

    const filteredArtists = artists.filter(a =>
        a.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        a.email.toLowerCase().includes(searchTerm.toLowerCase())
    );

    if (loading) return <div className="p-8 text-center text-text-muted">Loading artists...</div>;

    return (
        <div className="p-8 max-w-7xl mx-auto space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2">Artisti</h1>
                    <p className="text-text-muted">Gestisci gli artisti del tuo studio e i loro contratti.</p>
                </div>
                <button
                    onClick={() => setShowAddModal(true)}
                    className="flex items-center gap-2 bg-accent hover:bg-accent-hover text-white px-4 py-2 rounded-lg font-medium transition-colors"
                >
                    <Plus size={20} />
                    Aggiungi Artista
                </button>
            </div>

            <div className="flex items-center gap-4 bg-bg-secondary p-4 rounded-xl border border-border">
                <Search className="text-text-muted" size={20} />
                <input
                    type="text"
                    placeholder="Cerca per nome o email..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="bg-transparent border-none focus:ring-0 text-white placeholder-text-muted flex-1"
                />
                <button className="p-2 hover:bg-white/5 rounded-lg text-text-muted transition-colors">
                    <Filter size={20} />
                </button>
            </div>

            <div className="grid grid-cols-1 gap-4">
                {filteredArtists.map(artist => {
                    const contract = contracts[artist.id];
                    return (
                        <div
                            key={artist.id}
                            onClick={() => navigate(`/artists/${artist.id}`)}
                            className="bg-bg-secondary p-4 rounded-xl border border-border hover:border-accent/50 transition-all cursor-pointer group"
                        >
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-4">
                                    <div className="w-12 h-12 rounded-full bg-bg-tertiary flex items-center justify-center overflow-hidden">
                                        {artist.avatar_url ? (
                                            <img src={artist.avatar_url} alt={artist.full_name} className="w-full h-full object-cover" />
                                        ) : (
                                            <UserIcon className="text-text-muted" size={24} />
                                        )}
                                    </div>
                                    <div>
                                        <h3 className="font-semibold text-white group-hover:text-accent transition-colors">
                                            {artist.full_name}
                                        </h3>
                                        <p className="text-sm text-text-muted">{artist.email}</p>
                                        {artist.phone && (
                                            <button
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    window.open(`https://wa.me/${artist.phone?.replace(/\s+/g, '') || ''}`, '_blank');
                                                }}
                                                className="mt-1 flex items-center gap-1 text-xs font-medium text-green-500 hover:text-green-400 transition-colors"
                                            >
                                                <MessageCircle size={14} />
                                                <span>WhatsApp</span>
                                            </button>
                                        )}
                                    </div>
                                </div>

                                <div className="flex items-center gap-6">
                                    <div className="text-right">
                                        <p className="text-xs text-text-muted uppercase tracking-wider mb-1">Tipo Affitto</p>
                                        <div className="flex items-center gap-2 justify-end">
                                            {contract ? (
                                                <span className="bg-accent/10 text-accent px-2 py-1 rounded text-xs font-medium">
                                                    {contract.rent_type}
                                                </span>
                                            ) : (
                                                <span className="flex items-center gap-1 text-yellow-500 text-xs">
                                                    <AlertCircle size={12} /> Nessun Contratto
                                                </span>
                                            )}
                                        </div>
                                    </div>

                                    {contract && (
                                        <div className="text-right hidden sm:block">
                                            <p className="text-xs text-text-muted uppercase tracking-wider mb-1">Commissione</p>
                                            <span className="text-white font-mono">{contract.commission_rate}%</span>
                                        </div>
                                    )}

                                    {contract?.rent_type === 'PRESENCES' && (
                                        <div className="text-right hidden sm:block">
                                            <p className="text-xs text-text-muted uppercase tracking-wider mb-1">Presences</p>
                                            <span className="text-white font-mono">
                                                {contract.used_presences} / {contract.presence_package_limit || '∞'}
                                            </span>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    );
                })}

                {filteredArtists.length === 0 && (
                    <div className="text-center py-12 text-text-muted">
                        No artists found matching your search.
                    </div>
                )}
            </div>

            {/* Add Artist Modal */}
            {showAddModal && (
                <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
                    <div className="bg-bg-secondary p-6 rounded-xl border border-border w-full max-w-md shadow-2xl">
                        <h2 className="text-xl font-bold text-white mb-4">Add New Artist</h2>
                        <form onSubmit={handleAddArtist} className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-text-muted mb-1">Email Address</label>
                                <input
                                    type="email"
                                    required
                                    value={newArtistEmail}
                                    onChange={(e) => setNewArtistEmail(e.target.value)}
                                    placeholder="artist@example.com"
                                    className="w-full bg-bg-tertiary border border-border rounded-lg px-4 py-2 text-white focus:border-accent focus:outline-none"
                                />
                            </div>
                            <div className="flex justify-end gap-3 pt-4">
                                <button
                                    type="button"
                                    onClick={() => setShowAddModal(false)}
                                    className="px-4 py-2 text-text-muted hover:text-white transition-colors"
                                >
                                    Cancel
                                </button>
                                <button
                                    type="submit"
                                    disabled={adding}
                                    className="px-4 py-2 bg-accent hover:bg-accent-hover text-white rounded-lg font-medium transition-colors disabled:opacity-50"
                                >
                                    {adding ? 'Adding...' : 'Add Artist'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
};
