import React, { useState } from 'react';
import { User, Mail, Shield, Save } from 'lucide-react';
import { useAuth } from '../../auth/AuthContext';
import { api } from '../../../services/api';

export const ProfileSettings: React.FC = () => {
    const { user } = useAuth();
    const [name, setName] = useState(user?.full_name || '');
    const [email] = useState(user?.email || '');
    const [loading, setLoading] = useState(false);

    const handleSave = async () => {
        if (!user) return;
        setLoading(true);
        try {
            await api.settings.updateProfile(user.id, {
                full_name: name
            });
            alert('Profilo aggiornato con successo!');
            window.location.reload();
        } catch (error) {
            console.error('Failed to update profile:', error);
            alert('Errore durante l\'aggiornamento del profilo.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="space-y-6 max-w-2xl animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="flex items-center gap-6 mb-8">
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-bg-tertiary to-bg-secondary flex items-center justify-center border-2 border-border relative group cursor-pointer overflow-hidden">
                    {user?.avatar_url ? (
                        <img src={user.avatar_url} alt="Profile" className="w-full h-full object-cover" />
                    ) : (
                        <User size={40} className="text-text-muted" />
                    )}
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="text-xs text-white font-medium">Change</span>
                    </div>
                </div>
                <div>
                    <h3 className="text-xl font-bold text-white">{user?.full_name}</h3>
                    <p className="text-text-muted flex items-center gap-2 text-sm mt-1">
                        <Shield size={14} className="text-accent" />
                        {user?.role.replace('_', ' ')}
                    </p>
                </div>
            </div>

            <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-text-secondary mb-2">Full Name</label>
                        <div className="relative">
                            <input
                                type="text"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                className="w-full bg-bg-secondary border border-border rounded-lg pl-10 pr-4 py-2.5 text-white focus:ring-2 focus:ring-accent outline-none"
                            />
                            <User className="absolute left-3 top-2.5 text-text-muted" size={18} />
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-text-secondary mb-2">Email Address</label>
                        <div className="relative">
                            <input
                                type="email"
                                value={email}
                                disabled
                                className="w-full bg-bg-tertiary border border-border rounded-lg pl-10 pr-4 py-2.5 text-text-muted cursor-not-allowed"
                            />
                            <Mail className="absolute left-3 top-2.5 text-text-muted" size={18} />
                        </div>
                    </div>
                </div>

                <div className="pt-4">
                    <button
                        onClick={handleSave}
                        disabled={loading}
                        className="flex items-center gap-2 bg-accent hover:bg-accent-hover disabled:opacity-50 text-white px-6 py-2.5 rounded-lg font-medium transition-colors"
                    >
                        <Save size={18} />
                        <span>{loading ? 'Salvataggio...' : 'Save Changes'}</span>
                    </button>
                </div>
            </div>
        </div>
    );
};
