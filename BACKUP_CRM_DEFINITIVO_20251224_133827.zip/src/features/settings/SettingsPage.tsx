import React, { useState } from 'react';
import { User, Users, Building } from 'lucide-react';
import clsx from 'clsx';
import { useAuth } from '../auth/AuthContext';
import { ProfileSettings } from './components/ProfileSettings';
import { TeamSettings } from './components/TeamSettings';
import { StudioSettings } from './components/StudioSettings';

export const SettingsPage: React.FC = () => {
    const { user } = useAuth();
    const [activeTab, setActiveTab] = useState('profile');

    const tabs = [
        { id: 'profile', label: 'My Profile', icon: User },
        { id: 'team', label: 'Team Management', icon: Users },
        // Show Studio Info only for STUDIO_ADMIN (Owner)
        ...(user?.role === 'STUDIO_ADMIN' ? [{ id: 'studio', label: 'Studio Info', icon: Building }] : []),
    ];

    return (
        <div className="h-full flex flex-col md:flex-row gap-8">
            {/* Sidebar Tabs */}
            <div className="w-full md:w-64 flex-shrink-0">
                <h1 className="text-2xl font-bold text-white mb-6">Settings</h1>
                <nav className="space-y-2">
                    {tabs.map(tab => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={clsx(
                                "w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all text-left",
                                activeTab === tab.id
                                    ? "bg-accent text-white shadow-lg shadow-accent/20"
                                    : "text-text-muted hover:text-white hover:bg-bg-secondary"
                            )}
                        >
                            <tab.icon size={18} />
                            {tab.label}
                        </button>
                    ))}
                </nav>
            </div>

            {/* Content Area */}
            <div className="flex-1 min-h-[500px]">
                {activeTab === 'profile' && <ProfileSettings />}
                {activeTab === 'team' && <TeamSettings />}
                {activeTab === 'studio' && <StudioSettings />}
            </div>
        </div>
    );
};
