import { supabase } from '../../lib/supabase';
import type { IRepository, AuthSession, User, Appointment, Client, Transaction, FinancialStats, CourseMaterial, StudentAttendance, ClientConsent, ArtistContract, PresenceLog, MarketingCampaign, WaitlistEntry, Course, Communication, CommunicationReply, ConsentTemplate, CourseEnrollment, AttendanceLog, UserRole, Studio } from '../types';

export class SupabaseRepository implements IRepository {
    auth = {
        signIn: async (email: string, password: string): Promise<AuthSession> => {
            const { data, error } = await supabase.auth.signInWithPassword({ email, password });
            if (error) throw error;

            // Fetch checks for user role in 'users' table
            const { data: userData } = await supabase
                .from('users')
                .select('*')
                .eq('id', data.user.id)
                .single();

            // Default fallback if user record missing (auto-heal or error)
            const user: User = userData ? userData : {
                id: data.user.id,
                email: data.user.email!,
                full_name: data.user.user_metadata.full_name || 'User',
                role: 'STUDENT', // Default safety
                studio_id: 'default'
            };

            return {
                user,
                token: data.session.access_token
            };
        },
        signOut: async (): Promise<void> => {
            await supabase.auth.signOut();
        },
        getCurrentUser: async (): Promise<User | null> => {
            const { data } = await supabase.auth.getSession();
            if (!data.session) return null;

            const { data: userData } = await supabase
                .from('users')
                .select('*')
                .eq('id', data.session.user.id)
                .single();

            if (userData) return userData;
            return null;
        }
    };

    appointments = {
        list: async (start: Date, end: Date, artistId?: string): Promise<Appointment[]> => {
            let query = supabase
                .from('appointments')
                .select('*, client:clients(*)')
                .gte('start_time', start.toISOString())
                .lte('start_time', end.toISOString());

            if (artistId) {
                query = query.eq('artist_id', artistId);
            }

            const { data, error } = await query;
            if (error) throw error;
            return data as Appointment[];
        },
        create: async (data: Omit<Appointment, 'id'>): Promise<Appointment> => {
            const { data: newApt, error } = await supabase
                .from('appointments')
                .insert(data)
                .select()
                .single();
            if (error) throw error;
            return newApt;
        },
        update: async (id: string, data: Partial<Appointment>): Promise<Appointment> => {
            const { data: updated, error } = await supabase
                .from('appointments')
                .update(data)
                .eq('id', id)
                .select()
                .single();
            if (error) throw error;
            return updated;
        },
        delete: async (id: string): Promise<void> => {
            const { error } = await supabase
                .from('appointments')
                .delete()
                .eq('id', id);
            if (error) throw error;
        }
    };

    clients = {
        list: async (search?: string): Promise<Client[]> => {
            let query = supabase.from('clients').select('*');
            if (search) {
                query = query.or(`full_name.ilike.%${search}%,email.ilike.%${search}%`);
            }
            const { data, error } = await query;
            if (error) throw error;
            return data;
        },
        getById: async (id: string): Promise<Client | null> => {
            const { data, error } = await supabase.from('clients').select('*').eq('id', id).single();
            if (error) return null;
            return data;
        },
        create: async (data: Omit<Client, 'id'>): Promise<Client> => {
            const { data: newClient, error } = await supabase.from('clients').insert(data).select().single();
            if (error) throw error;
            return newClient;
        },
        update: async (id: string, data: Partial<Client>): Promise<Client> => {
            const { data: updated, error } = await supabase.from('clients').update(data).eq('id', id).select().single();
            if (error) throw error;
            return updated;
        }
    };

    financials = {
        listTransactions: async (startDate: Date, endDate: Date): Promise<Transaction[]> => {
            const { data, error } = await supabase
                .from('transactions')
                .select('*')
                .gte('date', startDate.toISOString())
                .lte('date', endDate.toISOString());
            if (error) throw error;
            return data;
        },
        getStats: async (_month: Date): Promise<FinancialStats> => {
            // Calculate stats via RPC or aggregation query
            // Mock implementation for now as Supabase aggregation is complex without Views
            return {
                revenue_today: 0,
                revenue_month: 0,
                expenses_month: 0
            };
        }
    };

    // Old academy block removed


    settings = {
        updateProfile: async (userId: string, data: Partial<User>): Promise<User> => {
            const { data: updated, error } = await supabase.from('users').update(data).eq('id', userId).select().single();
            if (error) throw error;
            return updated;
        },
        listTeamMembers: async (studioId: string): Promise<User[]> => {
            const { data, error } = await supabase.from('users').select('*').eq('studio_id', studioId);
            if (error) throw error;
            return data;
        },
        inviteMember: async (email: string, role: UserRole, studioId: string): Promise<User> => {
            // In real app, this invites via Supabase Auth
            // Here we simulate by creating a user record
            const { data, error } = await supabase.from('users').insert({ email, role, studio_id: studioId }).select().single();
            if (error) throw error;
            return data;
        },
        removeMember: async (userId: string): Promise<void> => {
            const { error } = await supabase.from('users').delete().eq('id', userId);
            if (error) throw error;
        },
        getStudio: async (studioId: string): Promise<Studio | null> => {
            const { data, error } = await supabase.from('studios').select('*').eq('id', studioId).single();
            if (error) return null;
            return data as Studio;
        },
        updateStudio: async (studioId: string, data: Partial<Studio>): Promise<Studio> => {
            const { data: updated, error } = await supabase.from('studios').update(data).eq('id', studioId).select().single();
            if (error) throw error;
            return updated as Studio;
        }
    };


    artists = {
        list: async (_studioId: string): Promise<User[]> => {
            throw new Error('Not implemented');
        },
        getContract: async (_artistId: string): Promise<ArtistContract | null> => {
            throw new Error('Not implemented');
        },
        updateContract: async (_artistId: string, _data: Partial<ArtistContract>): Promise<ArtistContract> => {
            throw new Error('Not implemented');
        },
        addPresence: async (_artistId: string, _studioId: string, _userId: string): Promise<void> => {
            throw new Error('Not implemented');
        },
        resetPresences: async (_artistId: string, _studioId: string, _userId: string, _note?: string): Promise<void> => {
            throw new Error('Not implemented');
        },
        getPresenceLogs: async (_artistId: string): Promise<PresenceLog[]> => {
            throw new Error('Not implemented');
        }
    };

    waitlist = {
        list: async (_studioId: string): Promise<WaitlistEntry[]> => { throw new Error('Not implemented'); },
        addToWaitlist: async (_data: Omit<WaitlistEntry, 'id' | 'created_at' | 'status'>, _signatureData?: string, _templateVersion?: number): Promise<WaitlistEntry> => { throw new Error('Not implemented'); },
        updateStatus: async (_id: string, _status: WaitlistEntry['status']): Promise<WaitlistEntry> => { throw new Error('Not implemented'); }
    };

    communications = {
        list: async (_studioId: string): Promise<Communication[]> => { throw new Error('Not implemented'); },
        create: async (_data: Omit<Communication, 'id' | 'created_at' | 'replies'>): Promise<Communication> => { throw new Error('Not implemented'); },
        delete: async (_id: string): Promise<void> => { throw new Error('Not implemented'); },
        addReply: async (_communicationId: string, _data: Omit<CommunicationReply, 'id' | 'created_at'>): Promise<CommunicationReply> => { throw new Error('Not implemented'); }
    };

    academy = {
        listMaterials: async (): Promise<CourseMaterial[]> => { throw new Error('Not implemented'); },
        recordAttendance: async (_studentId: string): Promise<StudentAttendance> => { throw new Error('Not implemented'); },
        listCourses: async (): Promise<Course[]> => { throw new Error('Not implemented'); },
        createCourse: async (_data: Omit<Course, 'id'>): Promise<Course> => { throw new Error('Not implemented'); },
        updateCourse: async (_id: string, _data: Partial<Course>): Promise<Course> => { throw new Error('Not implemented'); },
        deleteCourse: async (_id: string): Promise<void> => { throw new Error('Not implemented'); },
        assignStudent: async (_courseId: string, _studentId: string): Promise<void> => {
            throw new Error('Not implemented');
        },
        updateAttendance: async (_courseId: string, _studentId: string, _date: Date, _status: 'PRESENT' | 'ABSENT' | 'LATE'): Promise<void> => { throw new Error('Not implemented'); },
        getEnrollment: async (_courseId: string, _studentId: string): Promise<CourseEnrollment | null> => { throw new Error('Not implemented'); },
        updateEnrollment: async (_courseId: string, _studentId: string, _data: Partial<CourseEnrollment>): Promise<CourseEnrollment> => { throw new Error('Not implemented'); },
        logAttendance: async (_log: Omit<AttendanceLog, 'id' | 'created_at'>): Promise<void> => { throw new Error('Not implemented'); },
        getAttendanceLogs: async (_courseId: string, _studentId: string): Promise<AttendanceLog[]> => { throw new Error('Not implemented'); }
    };

    storage = {
        upload: async (_bucket: string, _path: string, _file: File): Promise<string> => {
            throw new Error('Not implemented');
        },
        delete: async (_bucket: string, _path: string): Promise<void> => {
            throw new Error('Not implemented');
        }
    };

    marketing = {
        listCampaigns: async (): Promise<MarketingCampaign[]> => { throw new Error('Not implemented'); },
        createCampaign: async (_data: Omit<MarketingCampaign, 'id' | 'created_at'>): Promise<MarketingCampaign> => { throw new Error('Not implemented'); },
        generateAIMessage: async (prompt: { goal: string; tone: string; length: string; customContext?: string }): Promise<string[]> => {
            // Placeholder since Supabase Edge Function is not connected.
            const ctx = prompt.customContext ? `"${prompt.customContext}"` : prompt.goal;
            return [
                `[Supabase] ${ctx} - Opzione 1`,
                `[Supabase] ${ctx} - Opzione 2`
            ];
        }
    };

    googleCalendar = {
        getAuthUrl: async (_userId: string): Promise<string> => { throw new Error('Not implemented'); },
        connect: async (_userId: string, _code: string): Promise<void> => { throw new Error('Not implemented'); },
        disconnect: async (_userId: string): Promise<void> => { throw new Error('Not implemented'); },
        syncEvents: async (_userId: string): Promise<{ synced: number }> => { throw new Error('Not implemented'); }
    };
    consents = {
        getTemplate: async (_studioId: string): Promise<ConsentTemplate | null> => { throw new Error('Not implemented'); },
        updateTemplate: async (_data: Partial<ConsentTemplate>): Promise<ConsentTemplate> => { throw new Error('Not implemented'); },
        listClientConsents: async (_clientId: string): Promise<ClientConsent[]> => { throw new Error('Not implemented'); },
        signConsent: async (_clientId: string, _templateId: string, _signatureData: string, _version: number, _role: string): Promise<ClientConsent> => { throw new Error('Not implemented'); },
        getStats: async (_studioId: string): Promise<{ signed_count: number; pending_count: number }> => { throw new Error('Not implemented'); }
    };
}
