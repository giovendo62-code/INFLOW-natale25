import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { StatsCard } from './components/StatsCard';
import {
    DollarSign,
    Calendar,
    Users,
    UserCheck,
    Clock,
    TrendingUp,
    BookOpen,
    CheckCircle,
    FileText,
    PlayCircle,
    Eye,
    EyeOff
} from 'lucide-react';
import { api } from '../../services/api';
import type { ArtistContract, Appointment, Studio, Course, CourseEnrollment } from '../../services/types';
import { format, addWeeks, startOfDay, endOfWeek, parseISO, isSameWeek } from 'date-fns';
import { it } from 'date-fns/locale';
import { useLayoutStore } from '../../stores/layoutStore';
import clsx from 'clsx';

export const Dashboard: React.FC = () => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const { isPrivacyMode, togglePrivacyMode } = useLayoutStore();
    const [contract, setContract] = React.useState<ArtistContract | null>(null);
    const [appointments, setAppointments] = React.useState<Appointment[]>([]);
    const [studio, setStudio] = React.useState<Studio | null>(null);

    // Student State
    const [studentCourse, setStudentCourse] = React.useState<Course | null>(null);
    const [studentEnrollment, setStudentEnrollment] = React.useState<CourseEnrollment | null>(null);

    const [loading, setLoading] = React.useState(true);

    if (!user) return null;

    React.useEffect(() => {
        const loadDashboardData = async () => {
            try {
                if (user.role === 'ARTIST') {
                    const c = await api.artists.getContract(user.id);
                    setContract(c);
                }

                if (user.role === 'STUDENT') {
                    // Fetch student course
                    const courses = await api.academy.listCourses();
                    const enrolledCourse = courses.find(c => c.student_ids.includes(user.id));

                    if (enrolledCourse) {
                        setStudentCourse(enrolledCourse);
                        const enroll = await api.academy.getEnrollment(enrolledCourse.id, user.id);
                        setStudentEnrollment(enroll);
                    }
                }

                if (user.studio_id) {
                    const s = await api.settings.getStudio(user.studio_id);
                    setStudio(s);
                }

                // Load appointments for today if needed, or skip for students? 
                // Student might check lessons in calendar? For now keeping same logic but maybe filtering for student?
                const today = startOfDay(new Date());
                const endNextWeek = endOfWeek(addWeeks(today, 1), { weekStartsOn: 1 });

                const appts = await api.appointments.list(today, endNextWeek);

                // Enhance appointments with client data if missing (assuming mock data structure)
                const enhancedAppts = await Promise.all(appts.map(async (appt) => {
                    if (appt.client) return appt;
                    const client = await api.clients.getById(appt.client_id);
                    return { ...appt, client: client || undefined };
                }));

                // Sort by date
                enhancedAppts.sort((a, b) => new Date(a.start_time).getTime() - new Date(b.start_time).getTime());

                setAppointments(enhancedAppts);
            } catch (error) {
                console.error('Error loading dashboard data:', error);
            } finally {
                setLoading(false);
            }
        };

        loadDashboardData();
    }, [user.id, user.role, user.studio_id]);

    const sendWhatsAppReminder = (appt: Appointment, type: 'WEEK_NOTICE' | 'CONFIRMATION') => {
        if (!appt.client?.phone) {
            alert('Numero di telefono non disponibile per questo cliente.');
            return;
        }

        const dateStr = format(parseISO(appt.start_time), "d MMMM", { locale: it });
        const timeStr = format(parseISO(appt.start_time), "HH:mm");
        const studioName = studio?.name || "InkFlow Studio";
        const location = studio ? `${studio.address}, ${studio.city}` : "il nostro studio";

        let message = '';

        if (type === 'WEEK_NOTICE') {
            message = `Ciao ${appt.client.full_name}, ti ricordiamo il tuo appuntamento per ${appt.service_name} il ${dateStr} alle ${timeStr} presso ${studioName} (${location}). A presto!`;
        } else {
            message = `Ciao ${appt.client.full_name}, confermiamo il tuo appuntamento presso ${studioName} per il ${dateStr} alle ${timeStr}. Per favore conferma la tua presenza. Grazie!`;
        }

        const encodedMessage = encodeURIComponent(message);
        window.open(`https://wa.me/${appt.client.phone.replace(/[^0-9]/g, '')}?text=${encodedMessage}`, '_blank');
    };

    const renderAdminWidgets = () => (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatsCard
                title="Incasso Oggi"
                value={isPrivacyMode ? '••••' : '€1,250'}
                change={isPrivacyMode ? undefined : "12%"}
                isPositive={true}
                icon={DollarSign}
                color="bg-green-500"
            />
            <StatsCard
                title="Appuntamenti Validi"
                value="8"
                change="4"
                isPositive={true}
                icon={Calendar}
                color="bg-blue-500"
            />
            <StatsCard
                title="Richieste in Attesa"
                value="12"
                icon={Users}
                color="bg-orange-500"
            />
            <StatsCard
                title="Staff Presente"
                value="5/6"
                icon={UserCheck}
                color="bg-purple-500"
            />
        </div>
    );

    const renderArtistWidgets = () => {
        // Calculate net earnings for artist
        // Mock calculation: sum of price of appointments in current month * commission %
        // In a real app this would come from a specific API or more complex logic
        const commissionRate = contract?.commission_rate || 50; // Default 50% if not set
        const netEarnings = isPrivacyMode ? '••••' : `€${((4200 * commissionRate) / 100).toLocaleString()}`; // Mock 4200 total revenue for now

        return (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <StatsCard
                    title="I Miei Appuntamenti"
                    value="3"
                    icon={Calendar}
                    color="bg-accent"
                />
                {contract?.rent_type === 'PRESENCES' && (
                    <StatsCard
                        title="Presenze Rimanenti"
                        value={isPrivacyMode ? '••••' : `${(contract.presence_package_limit || 0) - contract.used_presences}/${contract.presence_package_limit}`}
                        icon={Users}
                        color={(contract.presence_package_limit || 0) - contract.used_presences <= 2 ? "bg-red-500" : "bg-green-500"}
                    />
                )}
                <StatsCard
                    title="Prossimo Cliente"
                    value="tra 45m"
                    icon={Clock}
                    color="bg-blue-500"
                />
                <StatsCard
                    title="I Tuoi Guadagni (Netto)"
                    value={netEarnings}
                    change={isPrivacyMode ? undefined : "8%"}
                    isPositive={true}
                    icon={TrendingUp}
                    color="bg-green-500"
                />
            </div>
        );
    };

    const renderStudentWidgets = () => {
        if (!studentCourse) return (
            <div className="col-span-full text-center py-12 bg-bg-secondary rounded-lg border border-border text-text-muted">
                Non sei iscritto a nessun corso al momento.
            </div>
        );

        return (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8 col-span-full">
                {/* Course Info Card */}
                <div className="bg-bg-secondary p-6 rounded-xl border border-border flex flex-col justify-between">
                    <div>
                        <div className="flex items-center gap-3 mb-4">
                            <div className="p-2 bg-purple-500/20 rounded-lg text-purple-400">
                                <BookOpen size={24} />
                            </div>
                            <div>
                                <h3 className="text-lg font-bold text-white">Il Tuo Corso</h3>
                                <p className="text-sm text-text-muted">{studentCourse.title}</p>
                            </div>
                        </div>
                        <p className="text-text-secondary text-sm line-clamp-2 mb-4">
                            {studentCourse.description}
                        </p>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-text-muted pt-4 border-t border-border">
                        <span className="flex items-center gap-1"><Clock size={14} /> {studentCourse.duration}</span>
                        <span className="flex items-center gap-1"><FileText size={14} /> {studentCourse.materials?.length || 0} Moduli</span>
                    </div>
                </div>

                {/* Attendance Card */}
                <div className="bg-bg-secondary p-6 rounded-xl border border-border">
                    <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                        <UserCheck size={20} className="text-green-400" /> Le Tue Presenze
                    </h3>

                    {studentEnrollment ? (
                        <>
                            <div className="mb-2 flex justify-between items-end">
                                <span className="text-3xl font-bold text-white">{studentEnrollment.attended_days}</span>
                                <span className="text-sm text-text-muted mb-1">su {studentEnrollment.allowed_days} giorni totali</span>
                            </div>
                            <div className="w-full bg-bg-tertiary h-3 rounded-full overflow-hidden mb-4">
                                <div
                                    className={clsx("h-full transition-all duration-500",
                                        studentEnrollment.attended_days >= studentEnrollment.allowed_days ? "bg-red-500" : "bg-green-500")}
                                    style={{ width: `${Math.min((studentEnrollment.attended_days / studentEnrollment.allowed_days) * 100, 100)}%` }}
                                />
                            </div>
                            <p className="text-xs text-text-muted text-center">
                                {studentEnrollment.attended_days >= studentEnrollment.allowed_days
                                    ? "Hai completato i giorni previsti!"
                                    : "Continua così!"}
                            </p>
                        </>
                    ) : (
                        <p className="text-text-muted italic">Dati presenze non disponibili.</p>
                    )}
                </div>

                {/* Next Activity / Materials Quick Link */}
                <div className="bg-bg-secondary p-6 rounded-xl border border-border flex flex-col justify-between">
                    <h3 className="text-lg font-bold text-white mb-4">Materiale Didattico</h3>
                    <div className="space-y-3 mb-4 flex-1">
                        {(studentCourse.materials || []).slice(0, 3).map((mat, i) => (
                            <div key={i} className="flex items-center gap-3 p-2 rounded hover:bg-white/5 transition-colors cursor-pointer group">
                                <div className="text-accent group-hover:text-white transition-colors">
                                    {mat.type === 'VIDEO' ? <PlayCircle size={16} /> : <FileText size={16} />}
                                </div>
                                <span className="text-sm text-text-secondary group-hover:text-white truncate">{mat.title}</span>
                            </div>
                        ))}
                        {(studentCourse.materials || []).length === 0 && <p className="text-sm text-text-muted italic">Nessun materiale.</p>}
                    </div>

                    <button
                        onClick={() => navigate('/academy')}
                        className="w-full py-2 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 border border-indigo-500/20 rounded-lg text-sm font-bold transition-all"
                    >
                        Vai all'Academy
                    </button>
                </div>
            </div>
        );
    };

    return (
        <div className="h-full overflow-y-auto p-4 md:p-8 pt-20 md:pt-8">
            <div className="max-w-7xl mx-auto">
                <header className="mb-8 flex justify-between items-start">
                    <div>
                        <h1 className="text-3xl font-bold text-white mb-2">
                            {studio?.name || 'InkFlow CRM'}
                        </h1>
                        <p className="text-text-muted">
                            Bentornato, <span className="text-white font-medium">{user.full_name}</span>
                        </p>
                    </div>
                    {/* Mobile Privacy Toggle placed in Home */}
                    <button
                        onClick={togglePrivacyMode}
                        className="md:hidden p-2 bg-bg-secondary border border-border rounded-full text-text-muted hover:text-white transition-colors"
                        title={isPrivacyMode ? 'Mostra Valori' : 'Nascondi Valori'}
                    >
                        {isPrivacyMode ? <EyeOff size={20} /> : <Eye size={20} />}
                    </button>
                </header>

                {/* Role Based Content */}
                {(user.role === 'STUDIO_ADMIN' || user.role === 'MANAGER') && renderAdminWidgets()}
                {user.role === 'ARTIST' && renderArtistWidgets()}
                {user.role === 'STUDENT' && renderStudentWidgets()}

                {/* Shared Recent Activity Section - HIDDEN FOR STUDENTS */}
                {user.role !== 'STUDENT' && (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        <div className="lg:col-span-2 bg-bg-secondary border border-border rounded-lg p-6 min-h-[300px]">
                            <h3 className="text-lg font-bold text-white mb-4">
                                {user.role === 'ARTIST' ? 'Programma di Oggi' : 'Appuntamenti Recenti (Settimana Corrente e Prossima)'}
                            </h3>

                            {loading ? (
                                <div className="flex justify-center items-center h-48 text-text-muted">
                                    Caricamento...
                                </div>
                            ) : (
                                <div className="space-y-6">
                                    {/* Current Week Section */}
                                    <div>
                                        <h4 className="text-sm font-semibold text-text-muted mb-3 uppercase tracking-wider">
                                            Questa Settimana
                                        </h4>
                                        {appointments.filter(appt => isSameWeek(parseISO(appt.start_time), new Date(), { weekStartsOn: 1 })).length > 0 ? (
                                            <div className="space-y-3">
                                                {appointments
                                                    .filter(appt => isSameWeek(parseISO(appt.start_time), new Date(), { weekStartsOn: 1 }))
                                                    .map((appt) => (
                                                        <div key={appt.id} className="flex items-center justify-between p-4 bg-bg-primary rounded-lg border border-border/50 hover:border-accent/50 transition-colors">
                                                            <div className="flex items-center gap-4">
                                                                <div className="h-12 w-12 rounded-full bg-accent/10 flex items-center justify-center text-accent">
                                                                    <Calendar size={20} />
                                                                </div>
                                                                <div>
                                                                    <p className="font-medium text-white">
                                                                        {format(parseISO(appt.start_time), 'EEEE d MMMM', { locale: it })} - {format(parseISO(appt.start_time), 'HH:mm')}
                                                                    </p>
                                                                    <p className="text-sm text-text-muted">
                                                                        {appt.client?.full_name} • {appt.service_name}
                                                                    </p>
                                                                </div>
                                                            </div>

                                                            <div className="flex gap-2">
                                                                {user.role !== 'ARTIST' && (
                                                                    <button
                                                                        onClick={() => sendWhatsAppReminder(appt, 'CONFIRMATION')}
                                                                        className="p-2 text-green-400 hover:bg-green-400/10 rounded-lg transition-colors title='Invia Conferma'"
                                                                        title="Richiedi Conferma"
                                                                    >
                                                                        <CheckCircle size={18} />
                                                                    </button>
                                                                )}
                                                            </div>
                                                        </div>
                                                    ))}
                                            </div>
                                        ) : (
                                            <p className="text-sm text-text-muted italic">Nessun appuntamento questa settimana.</p>
                                        )}
                                    </div>

                                    {/* Next Week Section */}
                                    <div>
                                        <h4 className="text-sm font-semibold text-text-muted mb-3 uppercase tracking-wider">
                                            Prossima Settimana
                                        </h4>
                                        {appointments.filter(appt => !isSameWeek(parseISO(appt.start_time), new Date(), { weekStartsOn: 1 })).length > 0 ? (
                                            <div className="space-y-3">
                                                {appointments
                                                    .filter(appt => !isSameWeek(parseISO(appt.start_time), new Date(), { weekStartsOn: 1 }))
                                                    .map((appt) => (
                                                        <div key={appt.id} className="flex items-center justify-between p-4 bg-bg-primary rounded-lg border border-border/50 hover:border-accent/50 transition-colors">
                                                            <div className="flex items-center gap-4">
                                                                <div className="h-12 w-12 rounded-full bg-purple-500/10 flex items-center justify-center text-purple-500">
                                                                    <Calendar size={20} />
                                                                </div>
                                                                <div>
                                                                    <p className="font-medium text-white">
                                                                        {format(parseISO(appt.start_time), 'EEEE d MMMM', { locale: it })} - {format(parseISO(appt.start_time), 'HH:mm')}
                                                                    </p>
                                                                    <p className="text-sm text-text-muted">
                                                                        {appt.client?.full_name} • {appt.service_name}
                                                                    </p>
                                                                </div>
                                                            </div>

                                                            <div className="flex gap-2">
                                                                {user.role !== 'ARTIST' && (
                                                                    <>
                                                                        <button
                                                                            onClick={() => sendWhatsAppReminder(appt, 'WEEK_NOTICE')}
                                                                            className="p-2 text-blue-400 hover:bg-blue-400/10 rounded-lg transition-colors title='Invia Promemoria (1 Settimana)'"
                                                                            title="Promemoria 1 Settimana"
                                                                        >
                                                                            <Clock size={18} />
                                                                        </button>
                                                                        <button
                                                                            onClick={() => sendWhatsAppReminder(appt, 'CONFIRMATION')}
                                                                            className="p-2 text-green-400 hover:bg-green-400/10 rounded-lg transition-colors title='Invia Conferma'"
                                                                            title="Richiedi Conferma"
                                                                        >
                                                                            <CheckCircle size={18} />
                                                                        </button>
                                                                    </>
                                                                )}
                                                            </div>
                                                        </div>
                                                    ))}
                                            </div>
                                        ) : (
                                            <p className="text-sm text-text-muted italic">Nessun appuntamento per la prossima settimana.</p>
                                        )}
                                    </div>
                                </div>
                            )}
                        </div>

                        <div className="bg-bg-secondary border border-border rounded-lg p-6 min-h-[300px]">
                            <h3 className="text-lg font-bold text-white mb-4">Azioni Rapide</h3>
                            <div className="space-y-3">
                                <button
                                    onClick={() => navigate('/calendar')}
                                    className="w-full py-3 px-4 bg-accent hover:bg-accent-hover text-white rounded-lg font-medium transition-colors"
                                >
                                    + Nuovo Appuntamento
                                </button>
                                <button
                                    onClick={() => navigate('/communications')}
                                    className="w-full py-3 px-4 bg-bg-tertiary hover:bg-white/10 text-text-primary rounded-lg font-medium transition-colors border border-border"
                                >
                                    Controlla Messaggi
                                </button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
            );
};
