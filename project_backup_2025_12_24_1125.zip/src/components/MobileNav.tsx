import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Calendar, MessageSquare, Menu } from 'lucide-react';
import clsx from 'clsx';

export const MobileNav: React.FC = () => {
    return (
        <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-bg-secondary border-t border-border z-50 pb-safe">
            <div className="flex justify-around items-center h-16">
                <NavLink
                    to="/"
                    className={({ isActive }) => clsx("flex flex-col items-center gap-1 text-xs", isActive ? "text-accent" : "text-text-muted")}
                >
                    <LayoutDashboard size={24} />
                    <span>Home</span>
                </NavLink>
                <NavLink
                    to="/calendar"
                    className={({ isActive }) => clsx("flex flex-col items-center gap-1 text-xs", isActive ? "text-accent" : "text-text-muted")}
                >
                    <Calendar size={24} />
                    <span>Calendar</span>
                </NavLink>
                <NavLink
                    to="/chat"
                    className={({ isActive }) => clsx("flex flex-col items-center gap-1 text-xs", isActive ? "text-accent" : "text-text-muted")}
                >
                    <MessageSquare size={24} />
                    <span>Chat</span>
                </NavLink>
                <button className="flex flex-col items-center gap-1 text-xs text-text-muted">
                    <Menu size={24} />
                    <span>Menu</span>
                </button>
            </div>
        </nav>
    );
};
