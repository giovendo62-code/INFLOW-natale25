import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../features/auth/AuthContext';
import type { UserRole } from '../services/types';
import {
    LayoutDashboard,
    Calendar,
    Users,
    ClipboardList,
    DollarSign,
    GraduationCap,
    MessageSquare,
    Settings,
    LogOut,
    Palette,
    Eye,
    EyeOff,
    Megaphone,
    QrCode,
    X
} from 'lucide-react';
import clsx from 'clsx';

interface NavItem {
    label: string;
    path: string;
    icon: React.ElementType;
    allowedRoles: UserRole[];
}

const NAV_ITEMS: NavItem[] = [
    { label: 'Dashboard', path: '/', icon: LayoutDashboard, allowedRoles: ['STUDIO_ADMIN', 'MANAGER', 'ARTIST', 'STUDENT'] },
    { label: 'Calendario', path: '/calendar', icon: Calendar, allowedRoles: ['STUDIO_ADMIN', 'MANAGER', 'ARTIST'] },
    { label: 'Clienti', path: '/clients', icon: Users, allowedRoles: ['STUDIO_ADMIN', 'MANAGER', 'ARTIST'] },
    { label: 'Artisti', path: '/artists', icon: Palette, allowedRoles: ['STUDIO_ADMIN', 'MANAGER'] },
    { label: 'Lista Attesa', path: '/waitlist', icon: ClipboardList, allowedRoles: ['STUDIO_ADMIN', 'MANAGER'] },
    { label: 'Finanze', path: '/financials', icon: DollarSign, allowedRoles: ['STUDIO_ADMIN', 'MANAGER', 'ARTIST'] },
    { label: 'Marketing', path: '/marketing', icon: Megaphone, allowedRoles: ['STUDIO_ADMIN', 'MANAGER'] },
    { label: 'Academy', path: '/academy', icon: GraduationCap, allowedRoles: ['STUDIO_ADMIN', 'STUDENT'] },
    { label: 'Chat', path: '/chat', icon: MessageSquare, allowedRoles: ['STUDIO_ADMIN', 'MANAGER', 'ARTIST'] },
    { label: 'Impostazioni', path: '/settings', icon: Settings, allowedRoles: ['STUDIO_ADMIN', 'MANAGER'] },
];

import { useLayoutStore } from '../stores/layoutStore';

export const Sidebar: React.FC = () => {
    const { user, signOut } = useAuth();
    const { isSidebarVisible, isPrivacyMode, togglePrivacyMode } = useLayoutStore();

    const [isShareOpen, setIsShareOpen] = React.useState(false);

    if (!user) return null;
    // If hidden by global store (e.g. fullscreen calendar), return null
    if (!isSidebarVisible) return null;

    const filteredItems = NAV_ITEMS.filter(item => item.allowedRoles.includes(user.role));

    // Current App URL for sharing
    const appUrl = window.location.origin;

    return (
        <>
            <aside className="hidden md:flex flex-col w-64 h-screen bg-bg-secondary border-r border-border sticky top-0">
                <div className="p-6">
                    <h1 className="text-xl font-bold bg-gradient-to-r from-accent to-red-500 bg-clip-text text-transparent">
                        InkFlow
                    </h1>
                </div>

                <nav className="flex-1 px-4 space-y-2">
                    {filteredItems.map((item) => (
                        <NavLink
                            key={item.path}
                            to={item.path}
                            className={({ isActive }) => clsx(
                                'flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 group',
                                isActive
                                    ? 'bg-accent/10 text-accent font-medium'
                                    : 'text-text-secondary hover:bg-white/5 hover:text-white'
                            )}
                        >
                            <item.icon size={20} />
                            <span>{item.label}</span>
                        </NavLink>
                    ))}
                </nav>

                <div className="p-4 border-t border-border">
                    <button
                        onClick={togglePrivacyMode}
                        className="w-full flex items-center gap-3 px-4 py-2 mb-2 text-sm text-text-muted hover:text-white transition-colors"
                    >
                        {isPrivacyMode ? <EyeOff size={18} /> : <Eye size={18} />}
                        <span>{isPrivacyMode ? 'Mostra Valori' : 'Privacy Mode'}</span>
                    </button>

                    <button
                        onClick={() => setIsShareOpen(true)}
                        className="w-full flex items-center gap-3 px-4 py-2 mb-2 text-sm text-text-muted hover:text-white transition-colors"
                    >
                        <QrCode size={18} />
                        <span>Condividi App</span>
                    </button>

                    <div className="flex items-center gap-3 px-4 py-3 mb-2">
                        <img
                            src={user.avatar_url || `https://ui-avatars.com/api/?name=${user.full_name}`}
                            alt={user.full_name}
                            className="w-8 h-8 rounded-full bg-bg-tertiary"
                        />
                        <div className="flex-1 overflow-hidden">
                            <p className="text-sm font-medium text-white truncate">{user.full_name}</p>
                            <p className="text-xs text-text-muted truncate capitalize">{user.role.replace('_', ' ').toLowerCase()}</p>
                        </div>
                    </div>
                    <button
                        onClick={() => signOut()}
                        className="w-full flex items-center gap-3 px-4 py-2 text-sm text-text-muted hover:text-white transition-colors"
                    >
                        <LogOut size={18} />
                        <span>Sign Out</span>
                    </button>
                </div>
            </aside>

            {/* Full Screen Share Overlay */}
            {isShareOpen && (
                <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
                    <div className="bg-white rounded-2xl p-8 max-w-sm w-full text-center relative shadow-2xl transform transition-all scale-100">
                        <button
                            onClick={() => setIsShareOpen(false)}
                            className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 transition-colors p-2"
                        >
                            <X size={24} />
                        </button>

                        <h2 className="text-2xl font-bold text-gray-900 mb-2">Condividi InkFlow</h2>
                        <p className="text-gray-500 mb-6">Fai scansionare questo codice per accedere all'applicazione</p>

                        <div className="bg-gray-100 p-4 rounded-xl inline-block mb-6">
                            <img
                                src={`https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(appUrl)}`}
                                alt="App QR Code"
                                className="w-64 h-64 mix-blend-multiply"
                            />
                        </div>

                        <div className="flex flex-col gap-2">
                            <p className="text-xs text-gray-400 break-all bg-gray-50 p-2 rounded">{appUrl}</p>
                            <button
                                onClick={() => setIsShareOpen(false)}
                                className="w-full py-3 bg-gray-900 hover:bg-black text-white rounded-xl font-medium transition-colors"
                            >
                                Chiudi
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
};
