import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Mail, Phone, Calendar, Image, FileText, Activity, X, Save, Megaphone, Tag } from 'lucide-react';
import { api } from '../../services/api';
import type { Client } from '../../services/types';
import clsx from 'clsx';

import { Trash2, Eye } from 'lucide-react';

// Custom Drag & Drop Component removed, imported from components
import { DragDropUpload } from '../../components/DragDropUpload';

export const ClientProfile: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const [client, setClient] = useState<Client | null>(null);
    const [activeTab, setActiveTab] = useState('gallery'); // Default to Gallery for demo
    const [loading, setLoading] = useState(true);

    const [isEditing, setIsEditing] = useState(false);
    const [formData, setFormData] = useState<Partial<Client>>({});

    const isNewClient = id === 'new';

    useEffect(() => {
        if (isNewClient) {
            setClient({
                id: 'new',
                full_name: '',
                email: '',
                phone: '',
                whatsapp_broadcast_opt_in: false,
                preferred_styles: []
            } as Client);
            setFormData({});
            setIsEditing(true);
            setLoading(false);
        } else if (id) {
            loadClient(id);
        }
    }, [id]);

    const loadClient = async (clientId: string) => {
        if (clientId === 'new') return;
        setLoading(true);
        try {
            const data = await api.clients.getById(clientId);
            setClient(data);
        } finally {
            setLoading(false);
        }
    };

    const handleUpload = (file: File) => {
        // Mock upload functionality
        console.log('Uploading file:', file.name);
        alert(`Simulazione caricamento: ${file.name}`);
        // In a real app, we would upload to storage and update the client state here
    };

    const handleDeleteImage = (imgId: string) => {
        console.log('Deleting image:', imgId);
        alert('Simulazione eliminazione immagine');
    };

    const handleEditClick = () => {
        if (client) {
            setFormData({
                full_name: client.full_name,
                email: client.email,
                phone: client.phone,
                preferred_styles: client.preferred_styles,
                whatsapp_broadcast_opt_in: client.whatsapp_broadcast_opt_in
            });
            setIsEditing(true);
        }
    };

    const handleCancelClick = () => {
        if (isNewClient) {
            navigate('/clients');
            return;
        }
        setIsEditing(false);
        setFormData({});
    };

    const handleSaveClick = async () => {
        if (!client) return;
        try {
            if (isNewClient) {
                const newClient = await api.clients.create({
                    full_name: formData.full_name || 'Nuovo Cliente',
                    email: formData.email || '',
                    phone: formData.phone || '',
                    whatsapp_broadcast_opt_in: formData.whatsapp_broadcast_opt_in || false,
                    preferred_styles: formData.preferred_styles || []
                });
                navigate(`/clients/${newClient.id}`, { replace: true });
            } else {
                const updatedClient = await api.clients.update(client.id, formData);
                setClient(updatedClient);
                setIsEditing(false);
            }
        } catch (error) {
            console.error('Error saving client:', error);
            alert('Errore durante il salvataggio');
        }
    };

    const handleInputChange = (field: keyof Client, value: any) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    if (loading) return <div className="p-8 text-center text-text-muted">Caricamento profilo...</div>;
    if (!client) return <div className="p-8 text-center text-red-500">Cliente non trovato</div>;

    return (
        <div className="max-w-5xl mx-auto space-y-6">
            {/* Back Button */}
            <button
                onClick={() => navigate('/clients')}
                className="flex items-center gap-2 text-text-muted hover:text-white transition-colors"
            >
                <ArrowLeft size={20} />
                Torna ai Clienti
            </button>

            {/* Header Card */}
            <div className="bg-bg-secondary p-8 rounded-lg border border-border shadow-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                <div className="flex items-center gap-6 w-full md:w-auto">
                    <div className="w-20 h-20 rounded-full bg-gradient-to-br from-accent to-purple-600 flex items-center justify-center text-2xl font-bold text-white shadow-inner flex-shrink-0">
                        {client.full_name.charAt(0)}
                    </div>

                    {isEditing ? (
                        <div className="flex-1 space-y-3 w-full">
                            <input
                                type="text"
                                value={formData.full_name || ''}
                                onChange={(e) => handleInputChange('full_name', e.target.value)}
                                className="w-full bg-bg-tertiary border border-border rounded px-3 py-2 text-white font-bold text-xl"
                                placeholder="Nome Completo"
                            />
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                <input
                                    type="email"
                                    value={formData.email || ''}
                                    onChange={(e) => handleInputChange('email', e.target.value)}
                                    className="bg-bg-tertiary border border-border rounded px-3 py-1 text-white text-sm"
                                    placeholder="Email"
                                />
                                <input
                                    type="text"
                                    value={formData.phone || ''}
                                    onChange={(e) => handleInputChange('phone', e.target.value)}
                                    className="bg-bg-tertiary border border-border rounded px-3 py-1 text-white text-sm"
                                    placeholder="Telefono"
                                />
                            </div>
                            <div className="flex flex-col gap-2">
                                <label className="text-sm text-text-secondary flex items-center gap-2">
                                    <Tag size={16} /> Stili Preferiti
                                </label>
                                <div className="flex flex-wrap gap-2">
                                    {['Realistico', 'Minimal', 'Geometrico', 'Old School', 'Colorato', 'Tutti'].map((style) => {
                                        const isSelected = (formData.preferred_styles as string[])?.includes(style);
                                        return (
                                            <button
                                                key={style}
                                                onClick={() => {
                                                    const currentStyles = (formData.preferred_styles as string[]) || [];
                                                    const newStyles = isSelected
                                                        ? currentStyles.filter(s => s !== style)
                                                        : [...currentStyles, style];
                                                    handleInputChange('preferred_styles', newStyles);
                                                }}
                                                className={`px-3 py-1.5 rounded-full text-sm font-medium border transition-all ${isSelected
                                                        ? 'bg-accent text-white border-accent shadow-[0_0_10px_rgba(236,72,153,0.3)]'
                                                        : 'bg-bg-tertiary text-text-muted border-border hover:border-text-secondary hover:text-white'
                                                    }`}
                                            >
                                                {style}
                                            </button>
                                        );
                                    })}
                                </div>
                                <label className="flex items-center gap-2 cursor-pointer text-sm text-text-secondary select-none mt-2">
                                    <input
                                        type="checkbox"
                                        checked={formData.whatsapp_broadcast_opt_in || false}
                                        onChange={(e) => handleInputChange('whatsapp_broadcast_opt_in', e.target.checked)}
                                        className="rounded border-border bg-bg-tertiary text-accent focus:ring-accent"
                                    />
                                    Iscritto alla lista Broadcast WhatsApp
                                </label>
                            </div>
                        </div>
                    ) : (
                        <div>
                            <h1 className="text-3xl font-bold text-white mb-2">{client.full_name}</h1>
                            <div className="flex flex-col gap-2 text-text-secondary text-sm">
                                <div className="flex flex-col md:flex-row gap-4">
                                    <span className="flex items-center gap-2"><Mail size={16} /> {client.email}</span>
                                    <span className="flex items-center gap-2"><Phone size={16} /> {client.phone}</span>
                                </div>
                                {client.preferred_styles && client.preferred_styles.length > 0 && (
                                    <div className="flex items-center gap-2 mt-1">
                                        <Tag size={16} className="text-accent" />
                                        <div className="flex gap-2 flex-wrap">
                                            {client.preferred_styles.map((style, idx) => (
                                                <span key={idx} className="bg-accent/10 text-accent px-2 py-0.5 rounded text-xs border border-accent/20">
                                                    {style}
                                                </span>
                                            ))}
                                        </div>
                                    </div>
                                )}
                                <div className="flex items-center gap-2 mt-1">
                                    {client.whatsapp_broadcast_opt_in ? (
                                        <span className="flex items-center gap-1.5 text-green-500 bg-green-500/10 px-2 py-0.5 rounded text-xs border border-green-500/20">
                                            <Megaphone size={12} /> Broadcast Attivo
                                        </span>
                                    ) : (
                                        <span className="flex items-center gap-1.5 text-text-muted bg-bg-tertiary px-2 py-0.5 rounded text-xs border border-border">
                                            <Megaphone size={12} /> No Broadcast
                                        </span>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}
                </div>

                <div className="flex gap-3">
                    {isEditing ? (
                        <>
                            <button
                                onClick={handleCancelClick}
                                className="px-4 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg font-medium transition-colors flex items-center gap-2"
                            >
                                <X size={18} /> Annulla
                            </button>
                            <button
                                onClick={handleSaveClick}
                                className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium transition-colors flex items-center gap-2"
                            >
                                <Save size={18} /> Salva
                            </button>
                        </>
                    ) : (
                        <>
                            {!isNewClient && (
                                <button
                                    onClick={handleEditClick}
                                    className="px-4 py-2 bg-bg-tertiary hover:bg-white/10 border border-border rounded-lg text-white font-medium transition-colors"
                                >
                                    Modifica Profilo
                                </button>
                            )}
                            {!isNewClient && (
                                <button className="px-4 py-2 bg-accent hover:bg-accent-hover text-white rounded-lg font-medium transition-colors shadow-lg shadow-accent/20">
                                    Nuovo Appuntamento
                                </button>
                            )}
                        </>
                    )}
                </div>
            </div>

            {/* Tabs */}
            <div className="border-b border-border">
                <nav className="flex gap-6">
                    {[
                        { id: 'history', label: 'Storico', icon: Calendar },
                        { id: 'gallery', label: 'Galleria', icon: Image },
                        { id: 'consents', label: 'Consensi', icon: FileText },
                        { id: 'medical', label: 'Info Mediche', icon: Activity },
                    ].map(tab => (
                        <button
                            key={tab.id}
                            onClick={() => setActiveTab(tab.id)}
                            className={clsx(
                                "pb-4 flex items-center gap-2 text-sm font-medium transition-colors border-b-2",
                                activeTab === tab.id
                                    ? "text-accent border-accent"
                                    : "text-text-muted border-transparent hover:text-white hover:border-gray-700"
                            )}
                        >
                            <tab.icon size={18} />
                            {tab.label}
                        </button>
                    ))}
                </nav>
            </div>

            {/* Tab Content */}
            <div className="min-h-[300px]">
                {activeTab === 'history' && (
                    <div className="bg-bg-secondary rounded-lg border border-border p-8 text-center text-text-muted">
                        <Calendar size={48} className="mx-auto mb-4 opacity-20" />
                        <p>Nessun appuntamento nello storico.</p>
                    </div>
                )}
                {activeTab === 'gallery' && (
                    <div className="space-y-6">
                        {/* Upload Area */}
                        <DragDropUpload onUpload={handleUpload} />

                        {/* Gallery Grid */}
                        {client.images && client.images.length > 0 ? (
                            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                                {client.images.map((img) => (
                                    <div key={img.id} className="group relative aspect-square bg-bg-secondary rounded-lg overflow-hidden border border-border">
                                        <img
                                            src={img.url}
                                            alt={img.description || 'Cliente Image'}
                                            className="w-full h-full object-cover transition-transform group-hover:scale-105"
                                        />
                                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                                            <button
                                                onClick={() => window.open(img.url, '_blank')}
                                                className="p-2 bg-white/10 hover:bg-white/20 rounded-full text-white transition-colors"
                                                title="Visualizza"
                                            >
                                                <Eye size={20} />
                                            </button>
                                            <button
                                                onClick={() => handleDeleteImage(img.id)}
                                                className="p-2 bg-red-500/20 hover:bg-red-500/40 text-red-500 rounded-full transition-colors"
                                                title="Elimina"
                                            >
                                                <Trash2 size={20} />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="bg-bg-secondary rounded-lg border border-border p-8 text-center text-text-muted">
                                <Image size={48} className="mx-auto mb-4 opacity-20" />
                                <p>Nessuna immagine caricata.</p>
                            </div>
                        )}
                    </div>
                )}
                {activeTab === 'consents' && (
                    <div className="bg-bg-secondary rounded-lg border border-border p-8 text-center text-text-muted">
                        <FileText size={48} className="mx-auto mb-4 opacity-20" />
                        <p>Nessun consenso firmato.</p>
                    </div>
                )}
                {activeTab === 'medical' && (
                    <div className="bg-bg-secondary rounded-lg border border-border p-8 text-center text-text-muted">
                        <Activity size={48} className="mx-auto mb-4 opacity-20" />
                        <p>Nessuna nota medica registrata.</p>
                    </div>
                )}
            </div>
        </div>
    );
};
