import React, { useState, useEffect } from 'react';
import { BookOpen, FileText, PlayCircle, QrCode, CheckCircle, Download } from 'lucide-react';
import { api } from '../../services/api';
import type { CourseMaterial } from '../../services/types';
import clsx from 'clsx';

export const AcademyPage: React.FC = () => {
    const [materials, setMaterials] = useState<CourseMaterial[]>([]);
    const [loading, setLoading] = useState(true);
    const [showQr, setShowQr] = useState(false);

    useEffect(() => {
        loadMaterials();
    }, []);

    const loadMaterials = async () => {
        try {
            const data = await api.academy.listMaterials();
            setMaterials(data);
        } finally {
            setLoading(false);
        }
    };

    const handleScanMock = async () => {
        alert("Simulating QR Scan for Attendance...");
        await api.academy.recordAttendance("current-student-id");
        alert("Attendance Recorded!");
        setShowQr(false);
    };

    return (
        <div className="space-y-8">
            {/* Header */}
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-white">Academy</h1>
                    <p className="text-text-muted">Access course materials and track attendance.</p>
                </div>
                <button
                    onClick={() => setShowQr(!showQr)}
                    className={clsx(
                        "flex items-center gap-2 px-6 py-3 rounded-lg font-bold transition-all shadow-lg",
                        showQr ? "bg-red-500 hover:bg-red-600 text-white" : "bg-accent hover:bg-accent-hover text-white shadow-accent/20"
                    )}
                >
                    {showQr ? <CheckCircle size={20} /> : <QrCode size={20} />}
                    <span>{showQr ? "Close QR" : "Register Attendance"}</span>
                </button>
            </div>

            {/* QR Code Demo Section */}
            {showQr && (
                <div className="bg-white p-8 rounded-lg shadow-2xl max-w-sm mx-auto text-center transform transition-all animate-in fade-in zoom-in duration-300">
                    <h3 className="text-2xl font-bold text-black mb-4">Scan to Check-in</h3>
                    <div className="bg-gray-200 aspect-square w-full rounded-lg mb-4 flex items-center justify-center relative overflow-hidden group cursor-pointer" onClick={handleScanMock}>
                        <QrCode size={120} className="text-gray-800" />
                        <div className="absolute inset-0 bg-black/80 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <span className="text-white font-bold">Click to Simulate Scan</span>
                        </div>
                    </div>
                    <p className="text-gray-600 text-sm">Point your camera at the QR code to register your daily attendance.</p>
                </div>
            )}

            {/* Materials Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {loading ? (
                    <div className="col-span-full text-center text-text-muted py-12">Loading materials...</div>
                ) : materials.map(item => (
                    <div key={item.id} className="bg-bg-secondary border border-border rounded-lg p-6 hover:border-accent/50 transition-colors group">
                        <div className="flex items-start justify-between mb-4">
                            <div className="p-3 bg-bg-tertiary rounded-lg text-accent group-hover:bg-accent group-hover:text-white transition-colors">
                                {item.type === 'PDF' ? <FileText size={24} /> : item.type === 'VIDEO' ? <PlayCircle size={24} /> : <BookOpen size={24} />}
                            </div>
                            <span className="text-xs font-medium px-2 py-1 bg-bg-tertiary rounded text-text-muted">{item.type}</span>
                        </div>
                        <h3 className="text-lg font-bold text-white mb-2 group-hover:text-accent transition-colors">{item.title}</h3>
                        <p className="text-sm text-text-secondary mb-4">
                            Learn the fundamentals of {item.title.toLowerCase()} in this comprehensive module.
                        </p>
                        <button className="w-full py-2 border border-border rounded-lg text-text-muted hover:text-white hover:border-white transition-colors flex items-center justify-center gap-2">
                            <Download size={16} />
                            Download Material
                        </button>
                    </div>
                ))}
            </div>
        </div>
    );
};
