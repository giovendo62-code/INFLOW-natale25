import React, { useEffect, useState } from 'react';
import { useCalendar } from './hooks/useCalendar';
import { CalendarHeader } from './components/CalendarHeader';
import { MonthView } from './components/MonthView';
import { AppointmentDrawer } from './components/AppointmentDrawer';
import type { Appointment, User } from '../../services/types';
import { api } from '../../services/api';
import { useAuth } from '../auth/AuthContext';
import { useLayoutStore } from '../../stores/layoutStore';

import { Maximize2, Minimize2 } from 'lucide-react';
import { format, startOfWeek, addDays, startOfYear, addMonths } from 'date-fns';
import { it } from 'date-fns/locale';

export const Calendar: React.FC = () => {
    const { user } = useAuth();
    // Global layout store handles sidebar visibility
    const { isSidebarVisible, toggleSidebar } = useLayoutStore();

    const {
        currentDate,
        view,
        setView,
        appointments,
        next,
        prev,
        today,
        selectedArtistId,
        setSelectedArtistId,
        refresh // Ensure refresh is availables
    } = useCalendar();

    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    const [selectedDate, setSelectedDate] = useState<Date | null>(null);
    const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
    const [artists, setArtists] = useState<User[]>([]);

    useEffect(() => {
        const fetchArtists = async () => {
            if (user?.studio_id) {
                const members = await api.settings.listTeamMembers(user.studio_id);
                setArtists(members.filter(m => m.role === 'ARTIST'));
            }
        };
        fetchArtists();
    }, [user?.studio_id]);

    const handleDateClick = (date: Date) => {
        setSelectedDate(date);
        setSelectedAppointment(null);
        setIsDrawerOpen(true);
    };

    const handleAppointmentClick = (apt: Appointment) => {
        setSelectedAppointment(apt);
        setSelectedDate(new Date(apt.start_time));
        setIsDrawerOpen(true);
    };

    const handleSave = async (data: Partial<Appointment>) => {
        try {
            if (selectedAppointment) {
                // Update
                if (!selectedAppointment.id) return;
                await api.appointments.update(selectedAppointment.id, data);
            } else {
                // Create
                await api.appointments.create(data as Appointment);
            }
            await refresh(); // Refresh calendar data
            setIsDrawerOpen(false);
            setSelectedAppointment(null);
            setSelectedDate(null);
        } catch (error) {
            console.error('Failed to save appointment:', error);
            alert('Errore durante il salvataggio dell\'appuntamento');
        }
    };

    const handleDelete = async (id: string) => {
        try {
            await api.appointments.delete(id);
            await refresh();
            setIsDrawerOpen(false);
            setSelectedAppointment(null);
            setSelectedDate(null);
        } catch (error) {
            console.error('Failed to delete appointment:', error);
            alert('Errore durante l\'eliminazione dell\'appuntamento');
        }
    };

    const toggleFullscreen = () => {
        toggleSidebar();
    };

    // If sidebar is HIDDEN, we consider it fullscreen mode
    const isFullscreen = !isSidebarVisible;

    const WeekView = () => (
        <div className="flex-1 bg-bg-secondary border border-border rounded-lg overflow-auto">
            <div className="grid grid-cols-7 border-b border-border min-w-[800px]">
                {Array.from({ length: 7 }).map((_, i) => {
                    const date = addDays(startOfWeek(currentDate, { weekStartsOn: 1 }), i);
                    return (
                        <div key={i} className="p-4 text-center border-r border-border last:border-0 bg-bg-tertiary">
                            <div className="text-sm text-text-muted capitalize">{format(date, 'EEE', { locale: it })}</div>
                            <div className="text-xl font-bold text-white">{format(date, 'd')}</div>
                        </div>
                    );
                })}
            </div>
            <div className="p-8 text-center text-text-muted">
                Vista Settimanale (In Lavorazione)
            </div>
        </div>
    );

    const DayView = () => (
        <div className="flex-1 bg-bg-secondary border border-border rounded-lg p-6 flex flex-col items-center justify-center text-text-muted">
            <h3 className="text-xl text-white mb-2 capitalize">{format(currentDate, 'EEEE d MMMM yyyy', { locale: it })}</h3>
            Vista Giornaliera (In Lavorazione)
        </div>
    );

    const YearView = () => (
        <div className="flex-1 bg-bg-secondary border border-border rounded-lg overflow-auto p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {Array.from({ length: 12 }).map((_, i) => {
                    const monthStart = addMonths(startOfYear(currentDate), i);
                    return (
                        <div key={i} className="bg-bg-tertiary p-4 rounded-lg border border-border hover:border-accent transition-colors cursor-pointer" onClick={() => {
                            // Navigate to month view for this month (Not implemented in useCalendar yet fully but we can log)
                            console.log('Clicked month', i);
                        }}>
                            <h4 className="font-bold text-white mb-2 text-center capitalize">{format(monthStart, 'MMMM', { locale: it })}</h4>
                            <div className="aspect-square bg-bg-primary/50 rounded flex items-center justify-center text-xs text-text-muted">
                                Mini Calendar
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );

    return (
        <div className="h-[calc(100vh-100px)] flex flex-col relative transition-all duration-300">
            <div className="flex justify-end mb-2">
                <button
                    onClick={toggleFullscreen}
                    className="flex items-center gap-2 text-text-muted hover:text-white transition-colors text-sm"
                >
                    {isFullscreen ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
                    {isFullscreen ? 'Riduci' : 'Schermo Intero'}
                </button>
            </div>

            <CalendarHeader
                currentDate={currentDate}
                view={view}
                onViewChange={setView}
                onNext={next}
                onPrev={prev}
                onToday={today}
                artists={artists}
                selectedArtistId={selectedArtistId}
                onArtistChange={setSelectedArtistId}
                onNewAppointment={() => {
                    setSelectedDate(new Date());
                    setSelectedAppointment(null);
                    setIsDrawerOpen(true);
                }}
            />

            {view === 'month' && (
                <MonthView
                    currentDate={currentDate}
                    appointments={appointments}
                    onDateClick={handleDateClick}
                    onAppointmentClick={handleAppointmentClick}
                />
            )}
            {view === 'week' && <WeekView />}
            {view === 'day' && <DayView />}
            {view === 'year' && <YearView />}

            <AppointmentDrawer
                isOpen={isDrawerOpen}
                onClose={() => setIsDrawerOpen(false)}
                selectedDate={selectedDate}
                selectedAppointment={selectedAppointment}
                onSave={handleSave}
                onDelete={selectedAppointment ? handleDelete : undefined}
            />
        </div>
    );
};
