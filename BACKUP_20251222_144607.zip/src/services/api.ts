import type { IRepository } from './types';
import { MockRepository } from './mock';
import { SupabaseRepository } from './supabase';

const useMock = import.meta.env.VITE_USE_MOCK === 'true' || import.meta.env.VITE_USE_MOCK === true;

console.log(`Initializing API Service... Mock Mode: ${useMock}`);

export const api: IRepository = useMock
    ? new MockRepository()
    : new SupabaseRepository();
