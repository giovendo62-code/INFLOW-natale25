import React, { createContext, useContext, useEffect, useState } from 'react';
import type { User } from '../../services/types';
import { api } from '../../services/api';

interface AuthContextType {
    user: User | null;
    isAuthenticated: boolean;
    isLoading: boolean;
    signIn: (email: string, password?: string) => Promise<void>;
    signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
    const [user, setUser] = useState<User | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        checkUser();
    }, []);

    async function checkUser() {
        console.log('AuthContext: Checking user session...');
        try {
            const currentUser = await api.auth.getCurrentUser();
            console.log('AuthContext: User found:', currentUser ? currentUser.id : 'null');
            setUser(currentUser);
        } catch (error) {
            console.error('Failed to restore session:', error);
        } finally {
            console.log('AuthContext: Set loading false');
            setIsLoading(false);
        }
    }

    async function signIn(email: string, password?: string) {
        setIsLoading(true);
        try {
            const session = await api.auth.signIn(email, password || 'password-ignored-in-mock');
            setUser(session.user);
        } finally {
            setIsLoading(false);
        }
    }

    async function signOut() {
        setIsLoading(true);
        try {
            await api.auth.signOut();
            setUser(null);
        } finally {
            setIsLoading(false);
        }
    }

    return (
        <AuthContext.Provider value={{ user, isAuthenticated: !!user, isLoading, signIn, signOut }}>
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth() {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}
