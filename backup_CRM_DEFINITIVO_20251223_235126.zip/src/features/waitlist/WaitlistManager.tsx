import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../../services/api';
import type { WaitlistEntry } from '../../services/types';
import { Search, Filter, QrCode, CheckCircle, Clock, UserPlus, ArrowUpRight } from 'lucide-react';
import clsx from 'clsx';
import { useAuth } from '../auth/AuthContext';

export const WaitlistManager: React.FC = () => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const [entries, setEntries] = useState<WaitlistEntry[]>([]);
    const [loading, setLoading] = useState(true);
    const [showQr, setShowQr] = useState(false);
    const [activeTab, setActiveTab] = useState<'PENDING' | 'IN_PROGRESS' | 'COMPLETED'>('PENDING');

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        setLoading(true);
        try {
            const data = await api.waitlist.list(user?.studio_id || 'studio-1');
            setEntries(data);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    const handleStatusUpdate = async (id: string, status: WaitlistEntry['status']) => {
        try {
            await api.waitlist.updateStatus(id, status);
            loadData();
        } catch (err) {
            alert('Errore aggiornamento stato');
        }
    };

    const publicLink = `${window.location.origin}/public/waitlist/${user?.studio_id || 'studio-1'}`;

    const filteredEntries = entries.filter(entry => {
        if (activeTab === 'PENDING') return entry.status === 'PENDING';
        if (activeTab === 'IN_PROGRESS') return entry.status === 'IN_PROGRESS' || entry.status === 'CONTACTED';
        if (activeTab === 'COMPLETED') return entry.status === 'BOOKED' || entry.status === 'REJECTED';
        return true;
    });

    return (
        <div className="p-8 max-w-7xl mx-auto space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2">Lista d'Attesa</h1>
                    <p className="text-text-muted">Gestisci le richieste di appuntamento in arrivo.</p>
                </div>
                <div className="flex gap-3">
                    <button
                        onClick={() => setShowQr(!showQr)}
                        className="flex items-center gap-2 bg-bg-tertiary hover:bg-white/10 text-white px-4 py-2 rounded-lg border border-border transition-colors"
                    >
                        <QrCode size={20} />
                        {showQr ? 'Nascondi QR' : 'Mostra QR Code'}
                    </button>
                </div>
            </div>

            {/* QR Code Section */}
            {showQr && (
                <div className="bg-white p-6 rounded-xl border border-border shadow-xl max-w-sm mx-auto text-center transform transition-all animate-in fade-in slide-in-from-top-4">
                    <h3 className="text-black font-bold text-lg mb-4">Scansiona per Iscriverti</h3>
                    <div className="bg-gray-100 p-4 rounded-lg inline-block mb-4">
                        <img
                            src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(publicLink)}`}
                            alt="QR Code"
                            className="w-48 h-48 mix-blend-multiply"
                        />
                    </div>
                    <p className="text-gray-500 text-xs break-all px-4">{publicLink}</p>
                    <button
                        onClick={() => window.open(publicLink, '_blank')}
                        className="mt-4 text-accent text-sm font-medium hover:underline"
                    >
                        Apri Link
                    </button>
                    <button
                        onClick={() => window.print()}
                        className="mt-2 block w-full text-gray-400 text-xs hover:text-black"
                    >
                        Stampa
                    </button>
                </div>
            )}

            {/* Tabs */}
            <div className="flex border-b border-border mb-6">
                <button
                    onClick={() => setActiveTab('PENDING')}
                    className={clsx(
                        'px-6 py-3 border-b-2 font-medium transition-colors flex items-center gap-2',
                        activeTab === 'PENDING' ? 'border-accent text-accent' : 'border-transparent text-text-muted hover:text-white'
                    )}
                >
                    <Clock size={18} />
                    In Attesa
                    <span className="ml-2 bg-bg-tertiary text-text-secondary px-2 py-0.5 rounded-full text-xs">
                        {entries.filter(e => e.status === 'PENDING').length}
                    </span>
                </button>
                <button
                    onClick={() => setActiveTab('IN_PROGRESS')}
                    className={clsx(
                        'px-6 py-3 border-b-2 font-medium transition-colors flex items-center gap-2',
                        activeTab === 'IN_PROGRESS' ? 'border-accent text-accent' : 'border-transparent text-text-muted hover:text-white'
                    )}
                >
                    <UserPlus size={18} />
                    In Lavorazione
                    <span className="ml-2 bg-bg-tertiary text-text-secondary px-2 py-0.5 rounded-full text-xs">
                        {entries.filter(e => e.status === 'IN_PROGRESS' || e.status === 'CONTACTED').length}
                    </span>
                </button>
                <button
                    onClick={() => setActiveTab('COMPLETED')}
                    className={clsx(
                        'px-6 py-3 border-b-2 font-medium transition-colors flex items-center gap-2',
                        activeTab === 'COMPLETED' ? 'border-accent text-accent' : 'border-transparent text-text-muted hover:text-white'
                    )}
                >
                    <CheckCircle size={18} />
                    Completati
                    <span className="ml-2 bg-bg-tertiary text-text-secondary px-2 py-0.5 rounded-full text-xs">
                        {entries.filter(e => e.status === 'BOOKED' || e.status === 'REJECTED').length}
                    </span>
                </button>
            </div>

            {/* Filters (Mock UI) */}
            <div className="flex gap-4 mb-6">
                <div className="relative flex-1 max-w-sm">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted" size={18} />
                    <input
                        type="text"
                        placeholder="Cerca per nome..."
                        className="w-full bg-bg-secondary border border-border rounded-lg pl-10 pr-4 py-2 text-white focus:border-accent focus:outline-none"
                    />
                </div>
                <button className="flex items-center gap-2 px-4 py-2 bg-bg-secondary border border-border rounded-lg text-text-muted hover:text-white">
                    <Filter size={18} /> Filtra
                </button>
            </div>

            {/* List */}
            <div className="bg-bg-secondary rounded-xl border border-border overflow-hidden">
                <table className="w-full text-left">
                    <thead className="bg-bg-tertiary border-b border-border text-xs uppercase text-text-muted">
                        <tr>
                            <th className="p-4 font-medium">Cliente</th>
                            <th className="p-4 font-medium">Stili & Idea</th>
                            <th className="p-4 font-medium">Data Richiesta</th>
                            <th className="p-4 font-medium text-right">Azioni</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                        {loading ? (
                            <tr><td colSpan={4} className="p-8 text-center text-text-muted">Caricamento...</td></tr>
                        ) : filteredEntries.length === 0 ? (
                            <tr><td colSpan={4} className="p-8 text-center text-text-muted">Nessuna richiesta in questa sezione.</td></tr>
                        ) : (
                            filteredEntries.map(entry => (
                                <tr key={entry.id} className="hover:bg-bg-tertiary/50 transition-colors group">
                                    <td className="p-4">
                                        <div className="flex items-center justify-between gap-2">
                                            <div>
                                                <div className="font-medium text-white hover:text-accent cursor-pointer transition-colors" onClick={() => navigate(`/clients/${entry.client_id}`)}>
                                                    {entry.client_name}
                                                </div>
                                                <div className="text-xs text-text-muted truncate max-w-[150px]">{entry.email}</div>
                                            </div>
                                            <button
                                                onClick={() => navigate(`/clients/${entry.client_id}`)}
                                                className="text-text-muted hover:text-white p-1 rounded-md hover:bg-white/10 transition-colors"
                                                title="Vai alla scheda cliente"
                                            >
                                                <ArrowUpRight size={16} />
                                            </button>
                                        </div>
                                    </td>
                                    <td className="p-4">
                                        <div className="flex flex-wrap gap-1 mb-1">
                                            {entry.styles.map(s => (
                                                <span key={s} className="text-[10px] px-1.5 py-0.5 bg-accent/10 text-accent rounded border border-accent/20">{s}</span>
                                            ))}
                                        </div>
                                        <div className="text-sm text-text-secondary truncate max-w-xs" title={entry.description}>
                                            {entry.description || '-'}
                                        </div>
                                    </td>
                                    <td className="p-4 text-sm text-text-secondary">
                                        {new Date(entry.created_at).toLocaleDateString()}
                                    </td>
                                    <td className="p-4 text-right">
                                        <div className="flex items-center justify-end gap-2">
                                            {/* Actions for PENDING */}
                                            {entry.status === 'PENDING' && (
                                                <>
                                                    <button
                                                        onClick={() => handleStatusUpdate(entry.id, 'IN_PROGRESS')}
                                                        className="px-3 py-1.5 bg-blue-500/10 hover:bg-blue-500/20 text-blue-500 rounded-lg text-xs font-medium transition-colors border border-blue-500/20"
                                                    >
                                                        In Lavorazione
                                                    </button>
                                                    <button
                                                        onClick={() => handleStatusUpdate(entry.id, 'REJECTED')}
                                                        className="px-3 py-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-500 rounded-lg text-xs font-medium transition-colors border border-red-500/20"
                                                    >
                                                        Rifiuta
                                                    </button>
                                                </>
                                            )}

                                            {/* Actions for IN_PROGRESS / CONTACTED */}
                                            {(entry.status === 'IN_PROGRESS' || entry.status === 'CONTACTED') && (
                                                <>
                                                    <button
                                                        onClick={() => handleStatusUpdate(entry.id, 'BOOKED')}
                                                        className="px-3 py-1.5 bg-green-500/10 hover:bg-green-500/20 text-green-500 rounded-lg text-xs font-medium transition-colors border border-green-500/20"
                                                    >
                                                        Completa
                                                    </button>
                                                    <button
                                                        onClick={() => handleStatusUpdate(entry.id, 'PENDING')}
                                                        className="px-3 py-1.5 bg-bg-tertiary hover:bg-white/10 text-text-muted hover:text-white rounded-lg text-xs font-medium transition-colors border border-border"
                                                    >
                                                        Torna in Attesa
                                                    </button>
                                                </>
                                            )}

                                            {/* Actions for COMPLETED (Booked/Rejected) */}
                                            {(entry.status === 'BOOKED' || entry.status === 'REJECTED') && (
                                                <button
                                                    onClick={() => handleStatusUpdate(entry.id, 'IN_PROGRESS')}
                                                    className="px-3 py-1.5 bg-bg-tertiary hover:bg-white/10 text-text-muted hover:text-white rounded-lg text-xs font-medium transition-colors border border-border"
                                                >
                                                    Riapri
                                                </button>
                                            )}
                                        </div>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </div>
    );
};
