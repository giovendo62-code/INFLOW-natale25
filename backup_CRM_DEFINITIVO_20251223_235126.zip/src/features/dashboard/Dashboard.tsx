import React from 'react';
import { useAuth } from '../auth/AuthContext';
import { StatsCard } from './components/StatsCard';
import {
    DollarSign,
    Calendar,
    Users,
    UserCheck,
    Clock,
    TrendingUp,
    BookOpen,
    CheckCircle
} from 'lucide-react';
import { api } from '../../services/api';
import type { ArtistContract, Appointment, Studio } from '../../services/types';
import { format, addWeeks, startOfDay, endOfWeek, parseISO, isSameWeek } from 'date-fns';
import { it } from 'date-fns/locale';

export const Dashboard: React.FC = () => {
    const { user } = useAuth();
    const [contract, setContract] = React.useState<ArtistContract | null>(null);
    const [appointments, setAppointments] = React.useState<Appointment[]>([]);
    const [studio, setStudio] = React.useState<Studio | null>(null);
    const [loading, setLoading] = React.useState(true);

    if (!user) return null;

    React.useEffect(() => {
        const loadDashboardData = async () => {
            try {
                if (user.role === 'ARTIST') {
                    const c = await api.artists.getContract(user.id);
                    setContract(c);
                }

                if (user.studio_id) {
                    const s = await api.settings.getStudio(user.studio_id);
                    setStudio(s);
                }

                // Load appointments for current and next week
                const today = startOfDay(new Date());
                const endNextWeek = endOfWeek(addWeeks(today, 1), { weekStartsOn: 1 });

                const appts = await api.appointments.list(today, endNextWeek);

                // Enhance appointments with client data if missing (assuming mock data structure)
                const enhancedAppts = await Promise.all(appts.map(async (appt) => {
                    if (appt.client) return appt;
                    const client = await api.clients.getById(appt.client_id);
                    return { ...appt, client: client || undefined };
                }));

                // Sort by date
                enhancedAppts.sort((a, b) => new Date(a.start_time).getTime() - new Date(b.start_time).getTime());

                setAppointments(enhancedAppts);
            } catch (error) {
                console.error('Error loading dashboard data:', error);
            } finally {
                setLoading(false);
            }
        };

        loadDashboardData();
    }, [user.id, user.role]);

    const sendWhatsAppReminder = (appt: Appointment, type: 'WEEK_NOTICE' | 'CONFIRMATION') => {
        if (!appt.client?.phone) {
            alert('Numero di telefono non disponibile per questo cliente.');
            return;
        }

        const dateStr = format(parseISO(appt.start_time), "d MMMM", { locale: it });
        const timeStr = format(parseISO(appt.start_time), "HH:mm");
        const studioName = studio?.name || "InkFlow Studio";
        const location = studio ? `${studio.address}, ${studio.city}` : "il nostro studio";

        let message = '';

        if (type === 'WEEK_NOTICE') {
            message = `Ciao ${appt.client.full_name}, ti ricordiamo il tuo appuntamento per ${appt.service_name} il ${dateStr} alle ${timeStr} presso ${studioName} (${location}). A presto!`;
        } else {
            message = `Ciao ${appt.client.full_name}, confermiamo il tuo appuntamento presso ${studioName} per il ${dateStr} alle ${timeStr}. Per favore conferma la tua presenza. Grazie!`;
        }

        const encodedMessage = encodeURIComponent(message);
        window.open(`https://wa.me/${appt.client.phone.replace(/[^0-9]/g, '')}?text=${encodedMessage}`, '_blank');
    };

    const renderAdminWidgets = () => (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <StatsCard
                title="Incasso Oggi"
                value="€1,250"
                change="12%"
                isPositive={true}
                icon={DollarSign}
                color="bg-green-500"
            />
            <StatsCard
                title="Appuntamenti Validi"
                value="8"
                change="4"
                isPositive={true}
                icon={Calendar}
                color="bg-blue-500"
            />
            <StatsCard
                title="Richieste in Attesa"
                value="12"
                icon={Users}
                color="bg-orange-500"
            />
            <StatsCard
                title="Staff Presente"
                value="5/6"
                icon={UserCheck}
                color="bg-purple-500"
            />
        </div>
    );

    const renderArtistWidgets = () => (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <StatsCard
                title="I Miei Appuntamenti"
                value="3"
                icon={Calendar}
                color="bg-accent"
            />
            {contract?.rent_type === 'PRESENCES' && (
                <StatsCard
                    title="Presenze Rimanenti"
                    value={`${(contract.presence_package_limit || 0) - contract.used_presences}/${contract.presence_package_limit}`}
                    icon={Users}
                    color={(contract.presence_package_limit || 0) - contract.used_presences <= 2 ? "bg-red-500" : "bg-green-500"}
                />
            )}
            <StatsCard
                title="Prossimo Cliente"
                value="tra 45m"
                icon={Clock}
                color="bg-blue-500"
            />
            <StatsCard
                title="Incasso Mese"
                value="€4,200"
                change="8%"
                isPositive={true}
                icon={TrendingUp}
                color="bg-green-500"
            />
        </div>
    );

    const renderStudentWidgets = () => (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <StatsCard
                title="Prossima Lezione"
                value="Oggi, 14:00"
                icon={BookOpen}
                color="bg-purple-500"
            />
            <StatsCard
                title="Presenze"
                value="92%"
                isPositive={true}
                icon={UserCheck}
                color="bg-green-500"
            />
        </div>
    );

    return (
        <div className="max-w-7xl mx-auto">
            <header className="mb-8">
                <h1 className="text-3xl font-bold text-white mb-2">
                    Bentornato, {user.full_name}
                </h1>
                <p className="text-text-muted">
                    Ecco cosa succede nel tuo studio oggi.
                </p>
            </header>

            {/* Role Based Content */}
            {(user.role === 'STUDIO_ADMIN' || user.role === 'MANAGER') && renderAdminWidgets()}
            {user.role === 'ARTIST' && renderArtistWidgets()}
            {user.role === 'STUDENT' && renderStudentWidgets()}

            {/* Shared Recent Activity Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-bg-secondary border border-border rounded-lg p-6 min-h-[300px]">
                    <h3 className="text-lg font-bold text-white mb-4">
                        {user.role === 'ARTIST' ? 'Programma di Oggi' : 'Appuntamenti Recenti (Settimana Corrente e Prossima)'}
                    </h3>

                    {loading ? (
                        <div className="flex justify-center items-center h-48 text-text-muted">
                            Caricamento...
                        </div>
                    ) : (
                        <div className="space-y-6">
                            {/* Current Week Section */}
                            <div>
                                <h4 className="text-sm font-semibold text-text-muted mb-3 uppercase tracking-wider">
                                    Questa Settimana
                                </h4>
                                {appointments.filter(appt => isSameWeek(parseISO(appt.start_time), new Date(), { weekStartsOn: 1 })).length > 0 ? (
                                    <div className="space-y-3">
                                        {appointments
                                            .filter(appt => isSameWeek(parseISO(appt.start_time), new Date(), { weekStartsOn: 1 }))
                                            .map((appt) => (
                                                <div key={appt.id} className="flex items-center justify-between p-4 bg-bg-primary rounded-lg border border-border/50 hover:border-accent/50 transition-colors">
                                                    <div className="flex items-center gap-4">
                                                        <div className="h-12 w-12 rounded-full bg-accent/10 flex items-center justify-center text-accent">
                                                            <Calendar size={20} />
                                                        </div>
                                                        <div>
                                                            <p className="font-medium text-white">
                                                                {format(parseISO(appt.start_time), 'EEEE d MMMM', { locale: it })} - {format(parseISO(appt.start_time), 'HH:mm')}
                                                            </p>
                                                            <p className="text-sm text-text-muted">
                                                                {appt.client?.full_name} • {appt.service_name}
                                                            </p>
                                                        </div>
                                                    </div>

                                                    <div className="flex gap-2">
                                                        <button
                                                            onClick={() => sendWhatsAppReminder(appt, 'CONFIRMATION')}
                                                            className="p-2 text-green-400 hover:bg-green-400/10 rounded-lg transition-colors title='Invia Conferma'"
                                                            title="Richiedi Conferma"
                                                        >
                                                            <CheckCircle size={18} />
                                                        </button>
                                                    </div>
                                                </div>
                                            ))}
                                    </div>
                                ) : (
                                    <p className="text-sm text-text-muted italic">Nessun appuntamento questa settimana.</p>
                                )}
                            </div>

                            {/* Next Week Section */}
                            <div>
                                <h4 className="text-sm font-semibold text-text-muted mb-3 uppercase tracking-wider">
                                    Prossima Settimana
                                </h4>
                                {appointments.filter(appt => !isSameWeek(parseISO(appt.start_time), new Date(), { weekStartsOn: 1 })).length > 0 ? (
                                    <div className="space-y-3">
                                        {appointments
                                            .filter(appt => !isSameWeek(parseISO(appt.start_time), new Date(), { weekStartsOn: 1 }))
                                            .map((appt) => (
                                                <div key={appt.id} className="flex items-center justify-between p-4 bg-bg-primary rounded-lg border border-border/50 hover:border-accent/50 transition-colors">
                                                    <div className="flex items-center gap-4">
                                                        <div className="h-12 w-12 rounded-full bg-purple-500/10 flex items-center justify-center text-purple-500">
                                                            <Calendar size={20} />
                                                        </div>
                                                        <div>
                                                            <p className="font-medium text-white">
                                                                {format(parseISO(appt.start_time), 'EEEE d MMMM', { locale: it })} - {format(parseISO(appt.start_time), 'HH:mm')}
                                                            </p>
                                                            <p className="text-sm text-text-muted">
                                                                {appt.client?.full_name} • {appt.service_name}
                                                            </p>
                                                        </div>
                                                    </div>

                                                    <div className="flex gap-2">
                                                        <button
                                                            onClick={() => sendWhatsAppReminder(appt, 'WEEK_NOTICE')}
                                                            className="p-2 text-blue-400 hover:bg-blue-400/10 rounded-lg transition-colors title='Invia Promemoria (1 Settimana)'"
                                                            title="Promemoria 1 Settimana"
                                                        >
                                                            <Clock size={18} />
                                                        </button>
                                                        <button
                                                            onClick={() => sendWhatsAppReminder(appt, 'CONFIRMATION')}
                                                            className="p-2 text-green-400 hover:bg-green-400/10 rounded-lg transition-colors title='Invia Conferma'"
                                                            title="Richiedi Conferma"
                                                        >
                                                            <CheckCircle size={18} />
                                                        </button>
                                                    </div>
                                                </div>
                                            ))}
                                    </div>
                                ) : (
                                    <p className="text-sm text-text-muted italic">Nessun appuntamento per la prossima settimana.</p>
                                )}
                            </div>
                        </div>
                    )}
                </div>

                <div className="bg-bg-secondary border border-border rounded-lg p-6 min-h-[300px]">
                    <h3 className="text-lg font-bold text-white mb-4">Azioni Rapide</h3>
                    <div className="space-y-3">
                        <button className="w-full py-3 px-4 bg-accent hover:bg-accent-hover text-white rounded-lg font-medium transition-colors">
                            + Nuovo Appuntamento
                        </button>
                        <button className="w-full py-3 px-4 bg-bg-tertiary hover:bg-white/10 text-text-primary rounded-lg font-medium transition-colors border border-border">
                            Controlla Messaggi
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};
