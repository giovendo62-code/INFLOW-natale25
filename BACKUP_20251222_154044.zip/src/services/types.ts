export type UserRole = 'STUDIO_ADMIN' | 'MANAGER' | 'ARTIST' | 'STUDENT';

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  avatar_url?: string;
  studio_id?: string;
  integrations?: {
    google_calendar?: {
      is_connected: boolean;
      email?: string; // Connected Google Email
      calendar_id?: string;
      last_sync?: string;
      auto_sync: boolean;
    };
  };
}

export interface AuthSession {
  user: User | null;
  token: string | null;
}

export interface ClientImage {
  id: string;
  url: string;
  description?: string;
  uploaded_at: string;
}

export interface Client {
  id: string;
  full_name: string;
  email: string;
  phone: string;
  images?: ClientImage[];
  whatsapp_broadcast_opt_in?: boolean;
  preferred_styles?: string[];
  fiscal_code?: string;
  address?: string;
  city?: string;
  zip_code?: string;
}

export type AppointmentStatus = 'CONFIRMED' | 'PENDING' | 'COMPLETED' | 'NO_SHOW';

export interface Appointment {
  id: string;
  studio_id: string;
  artist_id: string;
  client_id: string;
  start_time: string; // ISO string
  end_time: string; // ISO string
  service_name: string;
  status: AppointmentStatus;
  notes?: string;
  client?: Client; // Joined data
  images?: string[]; // URLs of reference images
  price?: number; // Preventivo
  deposit?: number; // Acconto
}


export interface Transaction {
  id: string;
  studio_id: string;
  amount: number;
  type: 'INCOME' | 'EXPENSE';
  category: string;
  date: string; // ISO
  description?: string;
  artist_id?: string; // If commission related
}

export interface FinancialStats {
  revenue_today: number;
  revenue_month: number;
  expenses_month: number;
}

export interface CourseMaterial {
  id: string;
  title: string;
  type: 'PDF' | 'VIDEO' | 'LINK';
  url: string;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  duration: string;
  materials: CourseMaterial[];
  student_ids: string[];
}

export interface StudentAttendance {
  id: string;
  student_id: string;
  date: string;
  confirmed_by?: string;
}

export interface ConsentForm {
  id: string;
  title: string;
  content: string; // HTML or Markdown
  required_signature: boolean;
  version: string;
}

export interface ClientConsent {
  id: string;
  client_id: string;
  form_id: string;
  signed_at: string;
  signature_url?: string;
  status: 'SIGNED' | 'PENDING' | 'EXPIRED';
}

export interface IRepository {
  auth: {
    signIn(email: string, password: string): Promise<AuthSession>;
    signOut(): Promise<void>;
    getCurrentUser(): Promise<User | null>;
  };
  appointments: {
    list(start: Date, end: Date, artistId?: string): Promise<Appointment[]>;
    create(data: Omit<Appointment, 'id'>): Promise<Appointment>;
    update(id: string, data: Partial<Appointment>): Promise<Appointment>;
    delete(id: string): Promise<void>;
  };
  clients: {
    list(search?: string): Promise<Client[]>;
    getById(id: string): Promise<Client | null>;
    create(data: Omit<Client, 'id'>): Promise<Client>;
    update(id: string, data: Partial<Client>): Promise<Client>;
  };
  financials: {
    listTransactions(startDate: Date, endDate: Date): Promise<Transaction[]>;
    getStats(month: Date): Promise<FinancialStats>;
  };
  academy: {
    listMaterials(): Promise<CourseMaterial[]>;
    recordAttendance(studentId: string): Promise<StudentAttendance>;
    listCourses(): Promise<Course[]>;
    createCourse(data: Omit<Course, 'id'>): Promise<Course>;
    updateCourse(id: string, data: Partial<Course>): Promise<Course>;
    assignStudent(courseId: string, studentId: string): Promise<void>;
  };
  settings: {
    updateProfile(userId: string, data: Partial<User>): Promise<User>;
    listTeamMembers(studioId: string): Promise<User[]>;
    inviteMember(email: string, role: UserRole, studioId: string): Promise<User>;
    removeMember(userId: string): Promise<void>;
  };
  consents: {
    listForms(): Promise<ConsentForm[]>;
    getClientConsents(clientId: string): Promise<ClientConsent[]>;
    signConsent(clientId: string, formId: string, signatureData: string): Promise<ClientConsent>;
  };
  artists: {
    list(studioId: string): Promise<User[]>;
    getContract(artistId: string): Promise<ArtistContract | null>;
    updateContract(artistId: string, data: Partial<ArtistContract>): Promise<ArtistContract>;
    addPresence(artistId: string, studioId: string, userId: string): Promise<void>;
    resetPresences(artistId: string, studioId: string, userId: string, note?: string): Promise<void>;
    getPresenceLogs(artistId: string): Promise<PresenceLog[]>;
  };
  marketing: {
    listCampaigns(): Promise<MarketingCampaign[]>;
    createCampaign(data: Omit<MarketingCampaign, 'id' | 'created_at'>): Promise<MarketingCampaign>;
    generateAIMessage(prompt: { goal: string; tone: string; length: string }): Promise<string[]>;
  };
  googleCalendar: {
    getAuthUrl(userId: string): Promise<string>;
    connect(userId: string, code: string): Promise<void>;
    disconnect(userId: string): Promise<void>;
    syncEvents(userId: string): Promise<{ synced: number }>;
  };
  waitlist: {
    list(studioId: string): Promise<WaitlistEntry[]>;
    addToWaitlist(data: Omit<WaitlistEntry, 'id' | 'created_at' | 'status'>): Promise<WaitlistEntry>;
    updateStatus(id: string, status: WaitlistEntry['status']): Promise<WaitlistEntry>;
  };
}

export type RentType = 'FIXED' | 'PERCENTAGE' | 'PRESENCES';

export interface ArtistDocument {
  id: string;
  name: string;
  url: string;
  uploaded_at: string;
}

export interface ArtistContract {
  id: string;
  studio_id: string;
  artist_id: string;
  commission_rate: number; // 0-100
  rent_type: RentType;
  rent_fixed_amount?: number;
  rent_percent_rate?: number;
  presence_package_limit?: number;
  presence_price?: number;
  used_presences: number;
  presence_cycle_start?: string; // ISO
  presence_cycle_end?: string; // ISO
  updated_at: string;

  // Personal & Fiscal Data (Optional)
  vat_number?: string; // Partita IVA
  fiscal_code?: string; // Codice Fiscale
  address?: string;
  iban?: string;

  // Documents
  documents?: ArtistDocument[];
}

export interface PresenceLog {
  id: string;
  studio_id: string;
  artist_id: string;
  action: 'ADD' | 'RESET';
  created_by: string;
  created_at: string; // ISO
  note?: string;
}

// Marketing
export interface MarketingCampaign {
  id: string;
  studio_id: string;
  title: string;
  channel: 'WHATSAPP' | 'EMAIL' | 'SMS';
  message_text: string;
  ai_used: boolean;
  filters: {
    search?: string;
    broadcast_status?: 'ALL' | 'IN_BROADCAST' | 'NOT_IN_BROADCAST';
    styles?: string[];
  };
  recipients_count: number;
  status: 'DRAFT' | 'SENT';
  created_at: string;
  sent_at?: string;
}

export interface WaitlistEntry {
  id: string;
  studio_id: string;
  client_id: string;
  client_name: string; // Joined for display
  artist_pref_id?: string;
  styles: string[];
  description?: string;
  status: 'PENDING' | 'CONTACTED' | 'BOOKED' | 'REJECTED';
  created_at: string;
}
