import type { IRepository, AuthSession, User, Appointment, Client, Transaction, FinancialStats, CourseMaterial, StudentAttendance, ConsentForm, ClientConsent, ArtistContract, PresenceLog, MarketingCampaign, WaitlistEntry, Course } from '../types';

const MOCK_FORMS: ConsentForm[] = [
    { id: 'f1', title: 'General Liability Release', content: 'I hereby release...', required_signature: true, version: '1.0' },
    { id: 'f2', title: 'Aftercare Instructions', content: 'Keep it clean...', required_signature: false, version: '1.0' },
];

const MOCK_MATERIALS: CourseMaterial[] = [
    { id: '1', title: 'Hygiene & Safety Basics', type: 'PDF', url: '#' },
    { id: '2', title: 'Needle Depth Technique', type: 'VIDEO', url: '#' },
    { id: '3', title: 'Color Theory', type: 'PDF', url: '#' },
];

const MOCK_COURSES: Course[] = [
    {
        id: 'c1',
        title: 'Corso Base Tatuaggio',
        description: 'Dal disegno alla pelle, i fondamenti del mestiere.',
        duration: '3 Mesi',
        materials: [MOCK_MATERIALS[0], MOCK_MATERIALS[1]],
        student_ids: ['user-student']
    },
    {
        id: 'c2',
        title: 'Masterclass Realistico',
        description: 'Tecniche avanzate per ritratti e chiaroscuro.',
        duration: '2 Giorni',
        materials: [MOCK_MATERIALS[2]],
        student_ids: []
    }
];

const MOCK_TRANSACTIONS: Transaction[] = [
    { id: 'tx-1', studio_id: 'studio-1', amount: 150, type: 'INCOME', category: 'Tattoo Service', date: new Date().toISOString() },
    { id: 'tx-2', studio_id: 'studio-1', amount: 50, type: 'EXPENSE', category: 'Supplies', date: new Date().toISOString() },
    { id: 'tx-3', studio_id: 'studio-1', amount: 300, type: 'INCOME', category: 'Tattoo Service', date: new Date(new Date().setDate(new Date().getDate() - 2)).toISOString() },
];

const MOCK_CLIENTS: Client[] = [
    {
        id: 'client-1',
        full_name: 'Mario Rossi',
        email: 'mario@test.com',
        phone: '3331234567',
        images: [
            { id: 'img1', url: 'https://images.unsplash.com/photo-1598371839696-5c5bb7161438?auto=format&fit=crop&q=80&w=400', description: 'Tattoo Braccio', uploaded_at: new Date().toISOString() }
        ],
        whatsapp_broadcast_opt_in: true,
        preferred_styles: ['Traditional', 'Japanese']
    },
    {
        id: 'client-2',
        full_name: 'Luigi Verdi',
        email: 'luigi@test.com',
        phone: '3339876543',
        images: [],
        whatsapp_broadcast_opt_in: false,
        preferred_styles: ['Blackwork']
    },
    {
        id: 'client-3',
        full_name: 'Giulia Bianchi',
        email: 'giulia@test.com',
        phone: '3335556666',
        images: [],
        whatsapp_broadcast_opt_in: true,
        preferred_styles: ['Fine Line', 'Watercolor']
    },
];

const MOCK_USERS: User[] = [
    {
        id: 'user-admin',
        email: 'admin@inkflow.com',
        full_name: 'Studio Owner',
        role: 'STUDIO_ADMIN',
        studio_id: 'studio-1',
        avatar_url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=admin'
    },
    {
        id: 'user-manager',
        email: 'manager@inkflow.com',
        full_name: 'Shop Manager',
        role: 'MANAGER',
        studio_id: 'studio-1',
        avatar_url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=manager'
    },
    {
        id: 'user-artist',
        email: 'artist@inkflow.com',
        full_name: 'Tattoo Artist',
        role: 'ARTIST',
        studio_id: 'studio-1',
        avatar_url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=artist'
    },
    {
        id: 'user-student',
        email: 'student@inkflow.com',
        full_name: 'Academy Student',
        role: 'STUDENT',
        studio_id: 'studio-1',
        avatar_url: 'https://api.dicebear.com/7.x/avataaars/svg?seed=student'
    }
];

const MOCK_APPOINTMENTS: Appointment[] = [
    {
        id: 'apt-1',
        studio_id: 'studio-1',
        artist_id: 'user-artist',
        client_id: 'client-1',
        start_time: new Date(new Date().setHours(10, 0, 0, 0)).toISOString(), // Today 10:00
        end_time: new Date(new Date().setHours(13, 0, 0, 0)).toISOString(),   // Today 13:00
        service_name: 'Custom Designing',
        status: 'CONFIRMED',
        client: { id: 'client-1', full_name: 'Mario Rossi', email: 'mario@test.com', phone: '3331234567' },
        images: ['https://images.unsplash.com/photo-1598371839696-5c5bb7161438?auto=format&fit=crop&q=80&w=400']
    },
    {
        id: 'apt-2',
        studio_id: 'studio-1',
        artist_id: 'user-artist',
        client_id: 'client-2',
        start_time: new Date(new Date().setDate(new Date().getDate() + 1)).toISOString(), // Tomorrow
        end_time: new Date(new Date().setDate(new Date().getDate() + 1)).toISOString(),
        service_name: 'Touch up',
        status: 'PENDING',
        client: { id: 'client-2', full_name: 'Luigi Verdi', email: 'luigi@test.com', phone: '3339876543' },
        price: 80,
        deposit: 20
    }
];



// Marketing Mock Data
const MOCK_CAMPAIGNS: MarketingCampaign[] = [
    {
        id: 'camp-1',
        studio_id: 'studio-1',
        title: 'Promo Natale',
        channel: 'WHATSAPP',
        message_text: 'Ciao {{nome}}, auguri di Buon Natale da {{studio_nome}}! Per te uno sconto speciale...',
        ai_used: true,
        filters: { broadcast_status: 'IN_BROADCAST' },
        recipients_count: 50,
        status: 'SENT',
        created_at: new Date(Date.now() - 86400000).toISOString(),
        sent_at: new Date(Date.now() - 86000000).toISOString()
    }
];

export class MockRepository implements IRepository {
    // ... (previous implementations)

    marketing = {
        listCampaigns: async (): Promise<MarketingCampaign[]> => {
            await new Promise(resolve => setTimeout(resolve, 400));
            return [...MOCK_CAMPAIGNS].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        },
        createCampaign: async (data: Omit<MarketingCampaign, 'id' | 'created_at'>): Promise<MarketingCampaign> => {
            await new Promise(resolve => setTimeout(resolve, 500));
            const newCampaign: MarketingCampaign = {
                ...data,
                id: `camp-${Date.now()}`,
                created_at: new Date().toISOString()
            };
            MOCK_CAMPAIGNS.push(newCampaign);
            return newCampaign;
        },
        generateAIMessage: async (prompt: { goal: string; tone: string; length: string }): Promise<string[]> => {
            await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate AI processing

            const templates = [
                `Ciao {{nome}}, qui ${prompt.tone === 'Amichevole' ? 'i tuoi amici di' : 'lo staff di'} {{studio_nome}}. ${prompt.goal === 'Promo' ? 'Abbiamo una sorpresa per te!' : 'Volevamo sentirti.'}.`,
                `Ehi {{nome}}! 🌟 È tempo di un nuovo tattoo? ${prompt.goal === 'Promo' ? 'Approfitta della promo!' : 'Passa a trovarci.'}`,
                `Gentile {{nome}}, ${prompt.tone === 'Professionale' ? 'la informiamo che' : 'ti scriviamo perché'} ${prompt.goal}. Saluti, {{studio_nome}}.`
            ];

            return templates;
        }
    };

    // ... (auth, appointments, etc. - ensure existing implementations are preserved)
    auth = {
        signIn: async (email: string, _password?: string): Promise<AuthSession> => {
            // Simula latenza network
            await new Promise(resolve => setTimeout(resolve, 800));

            const user = MOCK_USERS.find(u => u.email === email);

            if (user) {
                const session = {
                    user,
                    token: 'mock-jwt-token-123'
                };
                localStorage.setItem('inkflow_mock_session', JSON.stringify(session));
                return session;
            }

            throw new Error('Invalid credentials');
        },

        signOut: async (): Promise<void> => {
            await new Promise(resolve => setTimeout(resolve, 400));
            localStorage.removeItem('inkflow_mock_session');
        },

        getCurrentUser: async (): Promise<User | null> => {
            const sessionStr = localStorage.getItem('inkflow_mock_session');
            if (!sessionStr) return null;
            try {
                const session = JSON.parse(sessionStr) as AuthSession;
                return session.user;
            } catch {
                return null;
            }
        }
    };

    appointments = {
        list: async (start: Date, end: Date, artistId?: string): Promise<Appointment[]> => {
            await new Promise(resolve => setTimeout(resolve, 500));

            let apts = MOCK_APPOINTMENTS.filter(a => {
                const aptTime = new Date(a.start_time).getTime();
                return aptTime >= start.getTime() && aptTime <= end.getTime();
            });

            // Filter by artist if provided (RBAC)
            if (artistId) {
                apts = apts.filter(a => a.artist_id === artistId);
            }
            return apts;
        },
        create: async (data: Omit<Appointment, 'id'>): Promise<Appointment> => {
            const newApt: Appointment = { ...data, id: `apt-${Date.now()}` };
            MOCK_APPOINTMENTS.push(newApt);
            return newApt;
        },
        update: async (id: string, data: Partial<Appointment>): Promise<Appointment> => {
            const idx = MOCK_APPOINTMENTS.findIndex(a => a.id === id);
            if (idx === -1) throw new Error('Not found');
            MOCK_APPOINTMENTS[idx] = { ...MOCK_APPOINTMENTS[idx], ...data };
            return MOCK_APPOINTMENTS[idx];
        },
        delete: async (id: string): Promise<void> => {
            const idx = MOCK_APPOINTMENTS.findIndex(a => a.id === id);
            if (idx === -1) throw new Error('Not found');
            MOCK_APPOINTMENTS.splice(idx, 1);
        }
    };

    clients = {
        list: async (search?: string): Promise<Client[]> => {
            await new Promise(resolve => setTimeout(resolve, 300));
            if (!search) return MOCK_CLIENTS;
            const lowerSearch = search.toLowerCase();
            return MOCK_CLIENTS.filter(c =>
                c.full_name.toLowerCase().includes(lowerSearch) ||
                c.email.toLowerCase().includes(lowerSearch) ||
                c.phone.includes(search)
            );
        },
        getById: async (id: string): Promise<Client | null> => {
            await new Promise(resolve => setTimeout(resolve, 200));
            return MOCK_CLIENTS.find(c => c.id === id) || null;
        },
        create: async (data: Omit<Client, 'id'>): Promise<Client> => {
            const newClient = { ...data, id: `client-${Date.now()}` };
            MOCK_CLIENTS.push(newClient);
            return newClient;
        },
        update: async (id: string, data: Partial<Client>): Promise<Client> => {
            const idx = MOCK_CLIENTS.findIndex(c => c.id === id);
            if (idx === -1) throw new Error('Not found');
            MOCK_CLIENTS[idx] = { ...MOCK_CLIENTS[idx], ...data };
            return MOCK_CLIENTS[idx];
        }
    };

    financials = {
        listTransactions: async (startDate: Date, endDate: Date): Promise<Transaction[]> => {
            await new Promise(resolve => setTimeout(resolve, 400));
            return MOCK_TRANSACTIONS.filter(t => {
                const d = new Date(t.date).getTime();
                return d >= startDate.getTime() && d <= endDate.getTime();
            });
        },
        getStats: async (_month: Date): Promise<FinancialStats> => {
            await new Promise(resolve => setTimeout(resolve, 300));
            return {
                revenue_today: 150,
                revenue_month: 4200,
                expenses_month: 1200
            };
        }
    };

    academy = {
        listMaterials: async (): Promise<CourseMaterial[]> => {
            await new Promise(resolve => setTimeout(resolve, 300));
            return MOCK_MATERIALS;
        },
        recordAttendance: async (studentId: string): Promise<StudentAttendance> => {
            await new Promise(resolve => setTimeout(resolve, 500));
            return {
                id: `att-${Date.now()}`,
                student_id: studentId,
                date: new Date().toISOString()
            };
        },
        listCourses: async (): Promise<Course[]> => {
            await new Promise(resolve => setTimeout(resolve, 400));
            return MOCK_COURSES;
        },
        createCourse: async (data: Omit<Course, 'id'>): Promise<Course> => {
            await new Promise(resolve => setTimeout(resolve, 600));
            const newCourse: Course = {
                ...data,
                id: `course-${Date.now()}`
            };
            MOCK_COURSES.push(newCourse);
            return newCourse;
        },
        updateCourse: async (id: string, data: Partial<Course>): Promise<Course> => {
            await new Promise(resolve => setTimeout(resolve, 400));
            const idx = MOCK_COURSES.findIndex(c => c.id === id);
            if (idx === -1) throw new Error('Course not found');
            MOCK_COURSES[idx] = { ...MOCK_COURSES[idx], ...data };
            return MOCK_COURSES[idx];
        },
        assignStudent: async (courseId: string, studentId: string): Promise<void> => {
            await new Promise(resolve => setTimeout(resolve, 400));
            const course = MOCK_COURSES.find(c => c.id === courseId);
            if (!course) throw new Error('Course not found');
            if (!course.student_ids.includes(studentId)) {
                course.student_ids.push(studentId);
            }
        }
    };

    settings = {
        updateProfile: async (userId: string, data: Partial<User>): Promise<User> => {
            await new Promise(resolve => setTimeout(resolve, 500));
            return {
                id: userId,
                email: 'updated@test.com',
                full_name: data.full_name || 'Updated Name',
                role: 'MANAGER',
                studio_id: 'studio-1',
                ...data
            };
        },
        listTeamMembers: async (studioId: string): Promise<User[]> => {
            await new Promise(resolve => setTimeout(resolve, 300));
            return MOCK_USERS.filter(u => u.studio_id === studioId);
        },
        inviteMember: async (email: string, role: any, studioId: string): Promise<User> => {
            await new Promise(resolve => setTimeout(resolve, 600));
            const newUser: User = {
                id: `u-${Date.now()}`,
                email,
                role,
                full_name: email.split('@')[0], // Simple mock name
                studio_id: studioId,
                avatar_url: `https://api.dicebear.com/7.x/avataaars/svg?seed=${email}`
            };
            MOCK_USERS.push(newUser);
            return newUser;
        },
        removeMember: async (userId: string): Promise<void> => {
            await new Promise(resolve => setTimeout(resolve, 400));
            const idx = MOCK_USERS.findIndex(u => u.id === userId);
            if (idx === -1) throw new Error('User not found');
            MOCK_USERS.splice(idx, 1);
        }
    };

    consents = {
        listForms: async (): Promise<ConsentForm[]> => {
            await new Promise(resolve => setTimeout(resolve, 300));
            return MOCK_FORMS;
        },
        getClientConsents: async (_clientId: string): Promise<ClientConsent[]> => {
            await new Promise(resolve => setTimeout(resolve, 400));
            return []; // Return empty list initially
        },
        signConsent: async (clientId: string, formId: string, _signatureData: string): Promise<ClientConsent> => {
            await new Promise(resolve => setTimeout(resolve, 800));
            return {
                id: `sc-${Date.now()}`,
                client_id: clientId,
                form_id: formId,
                signed_at: new Date().toISOString(),
                status: 'SIGNED',
                signature_url: 'mock-sig.png'
            };
        }
    };

    artists = {
        list: async (studioId: string): Promise<User[]> => {
            await new Promise(resolve => setTimeout(resolve, 300));
            return MOCK_USERS.filter(u => u.role === 'ARTIST' && u.studio_id === studioId);
        },
        getContract: async (artistId: string): Promise<ArtistContract | null> => {
            await new Promise(resolve => setTimeout(resolve, 300));
            return MOCK_CONTRACTS.find(c => c.artist_id === artistId) || null;
        },
        updateContract: async (artistId: string, data: Partial<ArtistContract>): Promise<ArtistContract> => {
            await new Promise(resolve => setTimeout(resolve, 500));
            let contractIndex = MOCK_CONTRACTS.findIndex(c => c.artist_id === artistId);

            if (contractIndex >= 0) {
                MOCK_CONTRACTS[contractIndex] = { ...MOCK_CONTRACTS[contractIndex], ...data, updated_at: new Date().toISOString() };
                return MOCK_CONTRACTS[contractIndex];
            } else {
                const newContract: ArtistContract = {
                    id: `contr-${Date.now()}`,
                    studio_id: 'studio-1', // Default for mock
                    artist_id: artistId,
                    commission_rate: 0,
                    rent_type: 'FIXED',
                    used_presences: 0,
                    updated_at: new Date().toISOString(),
                    ...data
                } as ArtistContract;
                MOCK_CONTRACTS.push(newContract);
                return newContract;
            }
        },
        addPresence: async (artistId: string, studioId: string, userId: string): Promise<void> => {
            await new Promise(resolve => setTimeout(resolve, 400));
            const contract = MOCK_CONTRACTS.find(c => c.artist_id === artistId);
            if (!contract) throw new Error('Contract not found');

            if (contract.rent_type !== 'PRESENCES') throw new Error('Not a presence contract');
            if (contract.presence_package_limit && contract.used_presences >= contract.presence_package_limit) {
                throw new Error('Presence limit reached');
            }

            contract.used_presences++;

            MOCK_PRESENCE_LOGS.unshift({
                id: `log-${Date.now()}`,
                studio_id: studioId,
                artist_id: artistId,
                action: 'ADD',
                created_by: userId,
                created_at: new Date().toISOString()
            });
        },
        resetPresences: async (artistId: string, studioId: string, userId: string, note?: string): Promise<void> => {
            await new Promise(resolve => setTimeout(resolve, 400));
            const contract = MOCK_CONTRACTS.find(c => c.artist_id === artistId);
            if (!contract) throw new Error('Contract not found');

            contract.used_presences = 0;
            contract.presence_cycle_start = new Date().toISOString();

            MOCK_PRESENCE_LOGS.unshift({
                id: `log-${Date.now()}`,
                studio_id: studioId,
                artist_id: artistId,
                action: 'RESET',
                created_by: userId,
                created_at: new Date().toISOString(),
                note
            });
        },
        getPresenceLogs: async (artistId: string): Promise<PresenceLog[]> => {
            await new Promise(resolve => setTimeout(resolve, 300));
            return MOCK_PRESENCE_LOGS.filter(l => l.artist_id === artistId);
        }
    };

    googleCalendar = {
        getAuthUrl: async (_userId: string): Promise<string> => {
            // Simulate Google OAuth URL
            await new Promise(resolve => setTimeout(resolve, 300));
            return 'https://accounts.google.com/o/oauth2/v2/auth?client_id=mock&redirect_uri=mock&response_type=code&scope=calendar';
        },
        connect: async (userId: string, _code: string): Promise<void> => {
            await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate token exchange
            const user = MOCK_USERS.find(u => u.id === userId);
            if (!user) throw new Error('User not found');

            user.integrations = {
                google_calendar: {
                    is_connected: true,
                    email: user.email.replace('@inkflow.com', '@gmail.com'), // Simulate Gmail
                    calendar_id: 'primary',
                    last_sync: new Date().toISOString(),
                    auto_sync: true
                }
            };
        },
        disconnect: async (userId: string): Promise<void> => {
            await new Promise(resolve => setTimeout(resolve, 500));
            const user = MOCK_USERS.find(u => u.id === userId);
            if (!user) throw new Error('User not found');

            if (user.integrations?.google_calendar) {
                user.integrations.google_calendar.is_connected = false;
                delete user.integrations.google_calendar.email;
            }
        },
        syncEvents: async (userId: string): Promise<{ synced: number }> => {
            await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate syncing
            const user = MOCK_USERS.find(u => u.id === userId);
            if (user?.integrations?.google_calendar) {
                user.integrations.google_calendar.last_sync = new Date().toISOString();
            }
            return { synced: Math.floor(Math.random() * 5) + 1 }; // Random mock count
        }
    };

    waitlist = {
        list: async (studioId: string): Promise<WaitlistEntry[]> => {
            await new Promise(resolve => setTimeout(resolve, 300));
            return MOCK_WAITLIST.filter(w => w.studio_id === studioId).sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        },
        addToWaitlist: async (data: Omit<WaitlistEntry, 'id' | 'created_at' | 'status'>): Promise<WaitlistEntry> => {
            await new Promise(resolve => setTimeout(resolve, 500));
            const newEntry: WaitlistEntry = {
                ...data,
                id: `wl-${Date.now()}`,
                status: 'PENDING',
                created_at: new Date().toISOString()
            };
            MOCK_WAITLIST.push(newEntry);
            return newEntry;
        },
        updateStatus: async (id: string, status: WaitlistEntry['status']): Promise<WaitlistEntry> => {
            await new Promise(resolve => setTimeout(resolve, 300));
            const idx = MOCK_WAITLIST.findIndex(w => w.id === id);
            if (idx === -1) throw new Error('Waitlist entry not found');
            MOCK_WAITLIST[idx] = { ...MOCK_WAITLIST[idx], status };
            return MOCK_WAITLIST[idx];
        }
    };
}

const MOCK_WAITLIST: WaitlistEntry[] = [
    {
        id: 'wl-1',
        studio_id: 'studio-1',
        client_id: 'client-3',
        client_name: 'Giulia Bianchi',
        styles: ['Fine Line'],
        status: 'PENDING',
        created_at: new Date(Date.now() - 86400000).toISOString(),
        description: 'Vorrei un fiore sul polso'
    }
];

const MOCK_CONTRACTS: ArtistContract[] = [
    {
        id: 'c1',
        studio_id: 'studio-1',
        artist_id: 'user-artist',
        commission_rate: 30,
        rent_type: 'PRESENCES',
        presence_package_limit: 10,
        presence_price: 50,
        used_presences: 7,
        updated_at: new Date().toISOString(),
        vat_number: 'IT12345678901',
        fiscal_code: 'RSSMRA85M01H501Z',
        address: 'Via Roma 1, Milano',
        documents: []
    }
];

const MOCK_PRESENCE_LOGS: PresenceLog[] = [];
