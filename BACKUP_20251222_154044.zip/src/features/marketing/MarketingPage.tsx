import React, { useState } from 'react';
import { MessageSquare, Users, Send, Clock, Sparkles } from 'lucide-react';
import clsx from 'clsx';
import { MessageEditor } from './components/MessageEditor';
import { ClientSegmenter } from './components/ClientSegmenter';
import { CampaignSummary } from './components/CampaignSummary';
import { CampaignHistory } from './components/CampaignHistory';
import type { MarketingCampaign } from '../../services/types';

type Tab = 'EDITOR' | 'SEGMENTS' | 'SUMMARY' | 'HISTORY';

export const MarketingPage: React.FC = () => {
    const [activeTab, setActiveTab] = useState<Tab>('EDITOR');
    const [draftCampaign, setDraftCampaign] = useState<Partial<MarketingCampaign>>({
        channel: 'WHATSAPP',
        message_text: '',
        filters: { broadcast_status: 'ALL', styles: [] },
        ai_used: false
    });

    const handleTabChange = (tab: Tab) => {
        setActiveTab(tab);
    };

    return (
        <div className="h-full flex flex-col user-select-none">
            {/* Header */}
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-6">
                <div>
                    <h1 className="text-2xl font-bold text-white">Marketing</h1>
                    <p className="text-text-muted">Crea campagne, segmenta i clienti e invia messaggi.</p>
                </div>
            </div>

            {/* Tabs */}
            <div className="flex border-b border-border mb-6 overflow-x-auto">
                <button
                    onClick={() => handleTabChange('EDITOR')}
                    className={clsx(
                        'flex items-center gap-2 px-6 py-3 border-b-2 font-medium transition-colors whitespace-nowrap',
                        activeTab === 'EDITOR'
                            ? 'border-accent text-accent'
                            : 'border-transparent text-text-muted hover:text-white'
                    )}
                >
                    <MessageSquare size={18} />
                    Crea Messaggio
                </button>
                <button
                    onClick={() => handleTabChange('SEGMENTS')}
                    className={clsx(
                        'flex items-center gap-2 px-6 py-3 border-b-2 font-medium transition-colors whitespace-nowrap',
                        activeTab === 'SEGMENTS'
                            ? 'border-accent text-accent'
                            : 'border-transparent text-text-muted hover:text-white'
                    )}
                >
                    <Users size={18} />
                    Seleziona Clienti
                </button>
                <button
                    onClick={() => handleTabChange('SUMMARY')}
                    className={clsx(
                        'flex items-center gap-2 px-6 py-3 border-b-2 font-medium transition-colors whitespace-nowrap',
                        activeTab === 'SUMMARY'
                            ? 'border-accent text-accent'
                            : 'border-transparent text-text-muted hover:text-white'
                    )}
                >
                    <Send size={18} />
                    Riepilogo & Invio
                </button>
                <button
                    onClick={() => handleTabChange('HISTORY')}
                    className={clsx(
                        'flex items-center gap-2 px-6 py-3 border-b-2 font-medium transition-colors whitespace-nowrap',
                        activeTab === 'HISTORY'
                            ? 'border-accent text-accent'
                            : 'border-transparent text-text-muted hover:text-white'
                    )}
                >
                    <Clock size={18} />
                    Storico
                </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto">
                {activeTab === 'EDITOR' && (
                    <MessageEditor
                        data={draftCampaign}
                        onChange={setDraftCampaign}
                        onNext={() => setActiveTab('SEGMENTS')}
                    />
                )}
                {activeTab === 'SEGMENTS' && (
                    <ClientSegmenter
                        data={draftCampaign}
                        onChange={setDraftCampaign}
                        onNext={() => setActiveTab('SUMMARY')}
                    />
                )}
                {activeTab === 'SUMMARY' && (
                    <CampaignSummary
                        data={draftCampaign}
                        onEdit={() => setActiveTab('EDITOR')}
                    />
                )}
                {activeTab === 'HISTORY' && (
                    <CampaignHistory />
                )}
            </div>
        </div>
    );
};
