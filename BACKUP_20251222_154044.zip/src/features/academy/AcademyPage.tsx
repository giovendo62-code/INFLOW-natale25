import React, { useState, useEffect } from 'react';
import { BookOpen, FileText, PlayCircle, QrCode, CheckCircle, Plus, Users, Clock, DollarSign, X } from 'lucide-react';
import { api } from '../../services/api';
import type { Course, CourseMaterial, User } from '../../services/types';
import clsx from 'clsx';

export const AcademyPage: React.FC = () => {
    const [courses, setCourses] = useState<Course[]>([]);
    const [loading, setLoading] = useState(true);
    const [view, setView] = useState<'LIST' | 'CREATE' | 'MANAGE'>('LIST');
    const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);

    // Form State
    const [newCourse, setNewCourse] = useState<Partial<Course>>({
        title: '',
        description: '',
        duration: '',
        materials: [],
        student_ids: []
    });

    // Manage State
    const [activeTab, setActiveTab] = useState<'INFO' | 'MATERIALS' | 'STUDENTS'>('INFO');

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        setLoading(true);
        try {
            const data = await api.academy.listCourses();
            setCourses(data);
        } finally {
            setLoading(false);
        }
    };

    const handleCreateCourse = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            if (!newCourse.title || !newCourse.duration) return;

            await api.academy.createCourse({
                title: newCourse.title,
                description: newCourse.description || '',
                duration: newCourse.duration,
                materials: [],
                student_ids: []
            });

            await loadData();
            setView('LIST');
            setNewCourse({ title: '', description: '', duration: '', materials: [], student_ids: [] });
        } catch (error) {
            console.error(error);
        }
    };

    const handleManageCourse = (course: Course) => {
        setSelectedCourse(course);
        setView('MANAGE');
        setActiveTab('INFO');
    };

    const handleUpdateCourse = async (updates: Partial<Course>) => {
        if (!selectedCourse) return;
        try {
            const updated = await api.academy.updateCourse(selectedCourse.id, updates);
            setSelectedCourse(updated);

            // Update local list
            setCourses(courses.map(c => c.id === updated.id ? updated : c));
        } catch (error) {
            console.error(error);
        }
    };

    const handleAddMaterial = async () => {
        const title = prompt("Titolo del materiale:");
        if (!title) return;

        const newMaterial: CourseMaterial = {
            id: `mat-${Date.now()}`,
            title,
            type: 'PDF',
            url: '#'
        };

        await handleUpdateCourse({
            materials: [...(selectedCourse?.materials || []), newMaterial]
        });
    };

    /* const handleAddStudent = async () => {
        const studentId = prompt("ID dello studente (es. user-student):");
        if (!studentId) return;
        if (selectedCourse?.student_ids.includes(studentId)) {
            alert("Studente già iscritto");
            return;
        }

        await handleUpdateCourse({
            student_ids: [...(selectedCourse?.student_ids || []), studentId]
        });
    }; */

    const handleAddStudentMock = async () => {
        // Mock selection of user-student
        const confirmed = window.confirm("Aggiungere lo studente 'Academy Student'?");
        if (!confirmed) return;
        if (selectedCourse?.student_ids.includes('user-student')) {
            alert("Studente già iscritto");
            return;
        }
        await handleUpdateCourse({
            student_ids: [...(selectedCourse?.student_ids || []), 'user-student']
        });
    };

    return (
        <div className="space-y-8 h-full flex flex-col">
            {/* Header */}
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-white">Academy</h1>
                    <p className="text-text-muted">Gestione corsi, materiali e studenti.</p>
                </div>
                {view === 'LIST' && (
                    <button
                        onClick={() => setView('CREATE')}
                        className="flex items-center gap-2 bg-accent hover:bg-accent-hover text-white px-4 py-2 rounded-lg font-bold transition-colors"
                    >
                        <Plus size={20} /> Nuovo Corso
                    </button>
                )}
                {view !== 'LIST' && (
                    <button
                        onClick={() => setView('LIST')}
                        className="flex items-center gap-2 bg-bg-tertiary hover:bg-white/10 text-white px-4 py-2 rounded-lg font-bold transition-colors border border-border"
                    >
                        Indietro
                    </button>
                )}
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto">
                {view === 'LIST' ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {loading ? (
                            <div className="col-span-full text-center text-text-muted py-12">Caricamento corsi...</div>
                        ) : courses.map(course => (
                            <div key={course.id} className="bg-bg-secondary border border-border rounded-xl overflow-hidden hover:border-accent/50 transition-all group flex flex-col">
                                <div className="p-6 flex-1">
                                    <div className="flex justify-between items-start mb-4">
                                        <div className="p-3 bg-bg-tertiary rounded-lg text-accent">
                                            <BookOpen size={24} />
                                        </div>
                                        <span className="text-xs font-medium px-2 py-1 bg-bg-tertiary rounded text-text-muted">
                                            {course.duration}
                                        </span>
                                    </div>
                                    <h3 className="text-xl font-bold text-white mb-2">{course.title}</h3>
                                    <p className="text-sm text-text-secondary line-clamp-3 mb-4">
                                        {course.description}
                                    </p>

                                    <div className="flex items-center gap-4 text-sm text-text-muted mt-auto pt-4 border-t border-border">
                                        <div className="flex items-center gap-1">
                                            <FileText size={16} />
                                            <span>{course.materials?.length || 0} Moduli</span>
                                        </div>
                                        <div className="flex items-center gap-1">
                                            <Users size={16} />
                                            <span>{course.student_ids?.length || 0} Studenti</span>
                                        </div>
                                    </div>
                                </div>
                                <div className="bg-bg-tertiary/50 p-4 border-t border-border">
                                    <button
                                        onClick={() => handleManageCourse(course)}
                                        className="w-full py-2 bg-white/5 hover:bg-white/10 text-white rounded-lg transition-colors text-sm font-medium"
                                    >
                                        Gestisci Corso
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : view === 'MANAGE' && selectedCourse ? (
                    <div className="bg-bg-secondary rounded-xl border border-border overflow-hidden shadow-2xl">
                        {/* Course Header */}
                        <div className="p-8 border-b border-border bg-bg-tertiary/20">
                            <h2 className="text-3xl font-bold text-white mb-2">{selectedCourse.title}</h2>
                            <p className="text-text-muted">{selectedCourse.description}</p>

                            <div className="flex gap-4 mt-6">
                                <button
                                    onClick={() => setActiveTab('INFO')}
                                    className={clsx("px-4 py-2 rounded-lg font-medium transition-colors", activeTab === 'INFO' ? "bg-accent text-white shadow-lg shadow-accent/20" : "text-text-secondary hover:text-white")}
                                >
                                    Info Gen.
                                </button>
                                <button
                                    onClick={() => setActiveTab('MATERIALS')}
                                    className={clsx("px-4 py-2 rounded-lg font-medium transition-colors", activeTab === 'MATERIALS' ? "bg-accent text-white shadow-lg shadow-accent/20" : "text-text-secondary hover:text-white")}
                                >
                                    Materiale Didattico
                                </button>
                                <button
                                    onClick={() => setActiveTab('STUDENTS')}
                                    className={clsx("px-4 py-2 rounded-lg font-medium transition-colors", activeTab === 'STUDENTS' ? "bg-accent text-white shadow-lg shadow-accent/20" : "text-text-secondary hover:text-white")}
                                >
                                    Corsisti
                                </button>
                            </div>
                        </div>

                        <div className="p-8">
                            {/* INFO TAB */}
                            {activeTab === 'INFO' && (
                                <div className="space-y-6 max-w-2xl">
                                    <div>
                                        <label className="block text-sm font-medium text-text-secondary mb-2">Titolo Corso</label>
                                        <input
                                            type="text"
                                            className="w-full bg-bg-tertiary border border-border rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-accent outline-none"
                                            value={selectedCourse.title}
                                            onChange={(e) => handleUpdateCourse({ title: e.target.value })}
                                        />
                                    </div>
                                    <div className="grid grid-cols-2 gap-6">
                                        <div>
                                            <label className="block text-sm font-medium text-text-secondary mb-2">Durata</label>
                                            <input
                                                type="text"
                                                className="w-full bg-bg-tertiary border border-border rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-accent outline-none"
                                                value={selectedCourse.duration}
                                                onChange={(e) => handleUpdateCourse({ duration: e.target.value })}
                                            />
                                        </div>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-text-secondary mb-2">Descrizione</label>
                                        <textarea
                                            className="w-full bg-bg-tertiary border border-border rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-accent outline-none h-32 resize-none"
                                            value={selectedCourse.description}
                                            onChange={(e) => handleUpdateCourse({ description: e.target.value })}
                                        />
                                    </div>
                                </div>
                            )}

                            {/* MATERIALS TAB */}
                            {activeTab === 'MATERIALS' && (
                                <div>
                                    <div className="flex justify-between items-center mb-6">
                                        <h3 className="text-xl font-bold text-white">Materiali Didattici</h3>
                                        <button
                                            onClick={handleAddMaterial}
                                            className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg font-medium transition-colors"
                                        >
                                            <Plus size={18} /> Aggiungi Materiale
                                        </button>
                                    </div>

                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                        {(selectedCourse.materials || []).length === 0 && (
                                            <p className="col-span-full text-text-muted italic">Nessun materiale caricato.</p>
                                        )}
                                        {(selectedCourse.materials || []).map((mat, idx) => (
                                            <div key={idx} className="bg-bg-tertiary p-4 rounded-lg border border-border flex items-center gap-4">
                                                <div className="p-2 bg-bg-secondary rounded text-accent">
                                                    {mat.type === 'VIDEO' ? <PlayCircle size={20} /> : <FileText size={20} />}
                                                </div>
                                                <div className="flex-1 overflow-hidden">
                                                    <p className="text-white font-medium truncate">{mat.title}</p>
                                                    <p className="text-xs text-text-muted">{mat.type}</p>
                                                </div>
                                                <button className="text-red-400 hover:text-red-300 transition-colors">
                                                    <X size={18} />
                                                </button>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {/* STUDENTS TAB */}
                            {activeTab === 'STUDENTS' && (
                                <div>
                                    <div className="flex justify-between items-center mb-6">
                                        <h3 className="text-xl font-bold text-white">Corsisti Iscritti</h3>
                                        <button
                                            onClick={handleAddStudentMock}
                                            className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg font-medium transition-colors"
                                        >
                                            <Users size={18} /> Aggiungi Studente
                                        </button>
                                    </div>

                                    <div className="space-y-2">
                                        {(selectedCourse.student_ids || []).length === 0 && (
                                            <p className="text-text-muted italic">Nessun studente iscritto.</p>
                                        )}
                                        {(selectedCourse.student_ids || []).map((sid, idx) => (
                                            <div key={idx} className="flex items-center justify-between p-4 bg-bg-tertiary rounded-lg border border-border">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-10 h-10 rounded-full bg-accent/20 flex items-center justify-center text-accent font-bold">
                                                        {sid.substring(0, 2).toUpperCase()}
                                                    </div>
                                                    <div>
                                                        <p className="text-white font-medium">Studente ID: {sid}</p>
                                                        <p className="text-xs text-text-muted">Iscritto</p>
                                                    </div>
                                                </div>
                                                <button className="text-text-muted hover:text-white px-3 py-1 rounded bg-bg-secondary border border-border">
                                                    Rimuovi
                                                </button>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                ) : (
                    /* Create Form */
                    <div className="max-w-2xl mx-auto bg-bg-secondary p-8 rounded-xl border border-border">
                        <h2 className="text-xl font-bold text-white mb-6">Crea Nuovo Corso</h2>
                        <form onSubmit={handleCreateCourse} className="space-y-6">
                            <div>
                                <label className="block text-sm font-medium text-text-secondary mb-2">Titolo Corso</label>
                                <input
                                    type="text"
                                    required
                                    className="w-full bg-bg-tertiary border border-border rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-accent outline-none"
                                    placeholder="es. Masterclass Realistico"
                                    value={newCourse.title}
                                    onChange={e => setNewCourse({ ...newCourse, title: e.target.value })}
                                />
                            </div>

                            <div className="grid grid-cols-2 gap-6">
                                <div>
                                    <label className="block text-sm font-medium text-text-secondary mb-2">Durata</label>
                                    <div className="relative">
                                        <input
                                            type="text"
                                            required
                                            className="w-full bg-bg-tertiary border border-border rounded-lg pl-10 pr-4 py-3 text-white focus:ring-2 focus:ring-accent outline-none"
                                            placeholder="es. 3 Mesi"
                                            value={newCourse.duration}
                                            onChange={e => setNewCourse({ ...newCourse, duration: e.target.value })}
                                        />
                                        <Clock className="absolute left-3 top-3.5 text-text-muted" size={18} />
                                    </div>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-text-secondary mb-2">Costo (Opzionale)</label>
                                    <div className="relative">
                                        <input
                                            type="number"
                                            className="w-full bg-bg-tertiary border border-border rounded-lg pl-10 pr-4 py-3 text-white focus:ring-2 focus:ring-accent outline-none"
                                            placeholder="0.00"
                                        />
                                        <DollarSign className="absolute left-3 top-3.5 text-text-muted" size={18} />
                                    </div>
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-text-secondary mb-2">Descrizione</label>
                                <textarea
                                    className="w-full bg-bg-tertiary border border-border rounded-lg px-4 py-3 text-white focus:ring-2 focus:ring-accent outline-none h-32 resize-none"
                                    placeholder="Descrivi gli obiettivi e il programma del corso..."
                                    value={newCourse.description}
                                    onChange={e => setNewCourse({ ...newCourse, description: e.target.value })}
                                />
                            </div>

                            {/* Section for Materials & Students could go here */}
                            <div className="p-4 bg-bg-tertiary/50 rounded-lg border border-border border-dashed text-center">
                                <p className="text-sm text-text-muted">Potrai aggiungere materiali didattici e assegnare studenti dopo aver creato il corso.</p>
                            </div>

                            <div className="flex justify-end gap-3 pt-4">
                                <button
                                    type="button"
                                    onClick={() => setView('LIST')}
                                    className="px-6 py-2 text-text-secondary hover:text-white transition-colors"
                                >
                                    Annulla
                                </button>
                                <button
                                    type="submit"
                                    className="px-8 py-2 bg-accent hover:bg-accent-hover text-white rounded-lg font-bold transition-all shadow-lg shadow-accent/20"
                                >
                                    Crea Corso
                                </button>
                            </div>
                        </form>
                    </div>
                )}
            </div>
        </div>
    );
};
